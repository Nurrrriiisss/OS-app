package com.example

import com.example.data.LifeOsRepository
import com.example.model.EnergyLevel
import com.example.model.PlanBlock
import com.example.model.TaskItem
import com.example.model.TaskPriority
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun repository_initialState_hasPrepopulatedData() {
        val repo = LifeOsRepository()
        val blocks = repo.scheduleBlocks.value
        val tasks = repo.tasks.value
        val habits = repo.habits.value

        assertTrue(blocks.isNotEmpty())
        assertTrue(tasks.isNotEmpty())
        assertTrue(habits.isNotEmpty())
    }

    @Test
    fun repository_toggleTask_updatesCompletion() {
        val repo = LifeOsRepository()
        val initialTask = repo.tasks.value.first()
        val initialCompleted = initialTask.isCompleted

        repo.toggleTask(initialTask.id)
        val updatedTask = repo.tasks.value.first { it.id == initialTask.id }

        assertEquals(!initialCompleted, updatedTask.isCompleted)
    }

    @Test
    fun repository_addPlanBlock_sortedChronologically() {
        val repo = LifeOsRepository()
        val newBlock = PlanBlock(
            title = "Night Reflection",
            timeStart = "22:00",
            timeEnd = "22:30",
            energyLevel = EnergyLevel.LOW
        )
        repo.addPlanBlock(newBlock)

        val lastBlock = repo.scheduleBlocks.value.last()
        assertEquals("Night Reflection", lastBlock.title)
    }
}
