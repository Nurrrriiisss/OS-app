package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.AiChatScreen
import com.example.ui.screens.AiPlannerScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FocusTimerScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.NotesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.UserProfileScreen
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueBorder
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.LifeOsTheme
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.util.configureAppCheck
import com.example.viewmodel.LifeOsViewModel
import com.example.viewmodel.OsScreen

class MainActivity : ComponentActivity() {

    private val viewModel: LifeOsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: App Check Foundation per Firebase AI Logic specification
        // Must configure with launch intent before any UI, ViewModels, or Firebase calls
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            LifeOsTheme {
                OsApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun OsApp(viewModel: LifeOsViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Listen for transient events
    LaunchedEffect(Unit) {
        viewModel.userEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    // Handle back button on sub-screens to return to Dashboard
    BackHandler(enabled = currentScreen != OsScreen.DASHBOARD) {
        viewModel.navigateTo(OsScreen.DASHBOARD)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            OsBottomNavigation(
                currentScreen = currentScreen,
                onSelectScreen = { viewModel.navigateTo(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(OffWhite)
        ) {
            Crossfade(targetState = currentScreen, label = "screen_crossfade") { screen ->
                when (screen) {
                    OsScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    OsScreen.TASKS -> TasksScreen(viewModel = viewModel)
                    OsScreen.AI_PLANNER -> AiPlannerScreen(viewModel = viewModel)
                    OsScreen.ANALYTICS -> AnalyticsScreen(viewModel = viewModel)
                    OsScreen.LEADERBOARD -> LeaderboardScreen(viewModel = viewModel)
                    OsScreen.AI_CHAT -> AiChatScreen(viewModel = viewModel)
                    OsScreen.FOCUS_TIMER -> FocusTimerScreen(viewModel = viewModel)
                    OsScreen.NOTES -> NotesScreen(viewModel = viewModel)
                    OsScreen.USER_PAGE -> LeaderboardScreen(viewModel = viewModel)
                    OsScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}

private data class NavItemData(
    val screen: OsScreen,
    val label: String,
    val icon: ImageVector,
    val testTag: String
)

@Composable
private fun OsBottomNavigation(
    currentScreen: OsScreen,
    onSelectScreen: (OsScreen) -> Unit
) {
    val navItems = listOf(
        NavItemData(OsScreen.DASHBOARD, "Home", Icons.Default.Home, "nav_dashboard"),
        NavItemData(OsScreen.TASKS, "Tasks", Icons.Default.CheckCircle, "nav_tasks"),
        NavItemData(OsScreen.AI_CHAT, "AI Chat", Icons.Default.Forum, "nav_ai_chat"),
        NavItemData(OsScreen.AI_PLANNER, "Planner", Icons.Default.CalendarMonth, "nav_planner"),
        NavItemData(OsScreen.ANALYTICS, "Analytics", Icons.Default.BarChart, "nav_analytics")
    )

    NavigationBar(
        containerColor = SurfaceWhite,
        contentColor = TextPrimary,
        tonalElevation = 6.dp,
        modifier = Modifier.border(1.dp, BorderLight)
    ) {
        navItems.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectScreen(item.screen) },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.label,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = item.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = BrandBlueDark,
                    unselectedIconColor = TextMuted,
                    selectedTextColor = BrandBlueDark,
                    unselectedTextColor = TextMuted,
                    indicatorColor = BrandBlueSubtle
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}
