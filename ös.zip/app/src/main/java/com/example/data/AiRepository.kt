package com.example.data

import android.util.Log
import com.example.model.BlockCategory
import com.example.model.ChatMessage
import com.example.model.EnergyLevel
import com.example.model.GoalBlueprint
import com.example.model.GoalPhase
import com.example.model.PlanBlock
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject

private const val TAG = "AiRepository"

class AiRepository {

    // Lazy initialization mandated by Firebase AI Logic skill
    private val generalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    // Schema for structured Daily Plan generation
    private val planSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "summaryStrategy" to Schema.string(description = "Executive summary of the day strategy"),
                "motivationalQuote" to Schema.string(description = "A short sharp Stoic or high-performance motivation quote"),
                "timeBlocks" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "title" to Schema.string(description = "Short actionable title for time block"),
                            "description" to Schema.string(description = "What to accomplish during this block"),
                            "timeStart" to Schema.string(description = "Start time in HH:mm format, e.g. 09:00"),
                            "timeEnd" to Schema.string(description = "End time in HH:mm format, e.g. 10:30"),
                            "category" to Schema.string(description = "Category: DEEP_WORK, STUDY, HEALTH, MEETING, ADMIN, or RECOVERY"),
                            "energyLevel" to Schema.string(description = "Energy level: HIGH, MODERATE, or LOW"),
                            "focusTip" to Schema.string(description = "Tactical focus tip to avoid distraction")
                        ),
                        optionalProperties = listOf("description", "focusTip")
                    ),
                    description = "Chronological array of time blocks spanning the active day"
                )
            )
        )
    }

    private val planModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = planSchema
            }
        )
    }

    // Schema for structured Goal Breakdown
    private val goalSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "strategy" to Schema.string(description = "High-level roadmap strategy to achieve the goal"),
                "immediateNextStep" to Schema.string(description = "The single highest-leverage first step to do today"),
                "phases" to Schema.array(
                    items = Schema.obj(
                        properties = mapOf(
                            "phaseNumber" to Schema.integer(description = "Sequence number 1 to 4"),
                            "phaseName" to Schema.string(description = "Descriptive phase title"),
                            "focusDescription" to Schema.string(description = "Core objective of this phase"),
                            "milestones" to Schema.array(
                                items = Schema.string(),
                                description = "Concrete measurable achievements in this phase"
                            )
                        )
                    ),
                    description = "Progressive phases to reach the goal"
                ),
                "dailyHabits" to Schema.array(
                    items = Schema.string(),
                    description = "Daily micro-habits that guarantee success"
                )
            )
        )
    }

    private val goalModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = goalSchema
            }
        )
    }

    // Schema for Task Decomposition
    private val taskSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "subtasks" to Schema.array(
                    items = Schema.string(),
                    description = "3 to 5 immediate, granular, sub-15 minute executable steps"
                )
            )
        )
    }

    private val taskModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = taskSchema
            }
        )
    }

    // Schema for Note Action Extraction
    private val noteSchema by lazy {
        Schema.obj(
            properties = mapOf(
                "summary" to Schema.string(description = "Concise 2-sentence executive summary"),
                "actionItems" to Schema.array(
                    items = Schema.string(),
                    description = "Actionable tasks extracted from the notes"
                )
            )
        )
    }

    private val noteModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = noteSchema
            }
        )
    }

    /**
     * Builds an optimized daily time-block plan with Gemini
     */
    suspend fun generateDailyPlan(
        userPrompt: String,
        wakeTime: String = "07:30",
        sleepTime: String = "23:00",
        hoursDeepWork: Int = 4,
        energyPeak: String = "Morning"
    ): Pair<String, List<PlanBlock>> {
        return try {
            val prompt = """
                You are ÖS Strategic Planning Engine. Create an optimized, realistic, chronological daily schedule.
                User's Primary Focus & Objectives for Today: $userPrompt
                Wake Time: $wakeTime
                Target Wind-Down Time: $sleepTime
                Target Deep Work Hours: $hoursDeepWork
                Energy Peak: $energyPeak
                
                Rules:
                - Create 5 to 8 chronological time blocks covering the day from $wakeTime to $sleepTime.
                - Align highest cognitive load tasks (DEEP_WORK) with the user's energy peak ($energyPeak).
                - Provide realistic buffer intervals, meals, and recovery periods.
                - Make time blocks specific and actionable.
            """.trimIndent()

            val response = withTimeout(60_000L) {
                planModel.generateContent(prompt)
            }

            val jsonText = response.text ?: throw IllegalStateException("Empty response from AI")
            val json = JSONObject(jsonText)
            val summary = json.optString("summaryStrategy", "Optimized Daily Blueprint")
            val blocksArray = json.getJSONArray("timeBlocks")
            val blocks = mutableListOf<PlanBlock>()

            for (i in 0 until blocksArray.length()) {
                val item = blocksArray.getJSONObject(i)
                val catStr = item.optString("category", "DEEP_WORK").uppercase()
                val category = try {
                    BlockCategory.valueOf(catStr)
                } catch (e: Exception) {
                    BlockCategory.DEEP_WORK
                }
                val energyStr = item.optString("energyLevel", "HIGH").uppercase()
                val energy = try {
                    EnergyLevel.valueOf(energyStr)
                } catch (e: Exception) {
                    EnergyLevel.MODERATE
                }

                blocks.add(
                    PlanBlock(
                        title = item.getString("title"),
                        description = item.optString("description", ""),
                        timeStart = item.optString("timeStart", "09:00"),
                        timeEnd = item.optString("timeEnd", "10:30"),
                        category = category,
                        energyLevel = energy,
                        tips = item.optString("focusTip", "")
                    )
                )
            }
            Pair(summary, blocks)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Plan generation timed out", e)
            throw IllegalStateException("AI Planning timed out after 60s. Please check your connection and try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Plan generation failed", e)
            throw e
        }
    }

    /**
     * Breaks down a long-term aspiration into phased roadmap and habits
     */
    suspend fun breakdownGoal(goalPrompt: String, timeframe: String = "30 Days"): GoalBlueprint {
        return try {
            val prompt = """
                You are ÖS Goal Architect. Break down this goal into a structured tactical execution plan:
                Goal: $goalPrompt
                Target Timeframe: $timeframe
                
                Break it into 3 to 4 sequential phases, key milestones for each phase, daily momentum habits, and an immediate next step to take within the next 24 hours.
            """.trimIndent()

            val response = withTimeout(60_000L) {
                goalModel.generateContent(prompt)
            }

            val jsonText = response.text ?: throw IllegalStateException("Empty response from AI")
            val json = JSONObject(jsonText)
            val strategy = json.optString("strategy", "")
            val immediateStep = json.optString("immediateNextStep", "")

            val phasesArray = json.getJSONArray("phases")
            val phases = mutableListOf<GoalPhase>()
            for (i in 0 until phasesArray.length()) {
                val p = phasesArray.getJSONObject(i)
                val mArray = p.getJSONArray("milestones")
                val milestones = (0 until mArray.length()).map { mArray.getString(it) }
                phases.add(
                    GoalPhase(
                        phaseNumber = p.optInt("phaseNumber", i + 1),
                        phaseName = p.getString("phaseName"),
                        focusDescription = p.optString("focusDescription", ""),
                        milestones = milestones
                    )
                )
            }

            val habitsArray = json.getJSONArray("dailyHabits")
            val habits = (0 until habitsArray.length()).map { habitsArray.getString(it) }

            GoalBlueprint(
                title = goalPrompt,
                targetTimeframe = timeframe,
                summaryStrategy = strategy,
                phases = phases,
                suggestedDailyHabits = habits,
                immediateNextAction = immediateStep
            )
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Goal breakdown timed out", e)
            throw IllegalStateException("Goal breakdown timed out. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Goal breakdown failed", e)
            throw e
        }
    }

    /**
     * Decomposes a daunting task into immediate micro-steps
     */
    suspend fun decomposeTask(taskTitle: String): List<String> {
        return try {
            val prompt = "Break down the following task into 3-5 immediate, frictionless subtasks that can be executed in under 15 minutes each: '$taskTitle'"
            val response = withTimeout(30_000L) {
                taskModel.generateContent(prompt)
            }
            val json = JSONObject(response.text ?: "{}")
            val arr = json.getJSONArray("subtasks")
            (0 until arr.length()).map { arr.getString(it) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Decompose task failed", e)
            throw e
        }
    }

    /**
     * Analyzes notes to produce an executive summary and extracted action tasks
     */
    suspend fun summarizeAndExtract(noteTitle: String, noteContent: String): Pair<String, List<String>> {
        return try {
            val prompt = """
                Analyze this note from ÖS Second Brain:
                Title: $noteTitle
                Content: $noteContent
                
                Provide a crisp 2-sentence summary and extract any actionable tasks.
            """.trimIndent()

            val response = withTimeout(30_000L) {
                noteModel.generateContent(prompt)
            }
            val json = JSONObject(response.text ?: "{}")
            val summary = json.optString("summary", "Summary extracted")
            val arr = json.getJSONArray("actionItems")
            val items = (0 until arr.length()).map { arr.getString(it) }
            Pair(summary, items)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Note analysis failed", e)
            throw e
        }
    }

    /**
     * Multi-turn chat with ÖS Strategic Copilot with dynamic systemInstruction and streaming response
     */
    fun chatStream(
        userMessage: String,
        history: List<ChatMessage>,
        systemPrompt: String = "You are the ÖS Executive Copilot. You are an expert strategist, productivity engineer, and high-performance coach. Provide actionable, concise, crisp, and high-leverage answers. Use bullet points and clear step-by-step guidance."
    ): Flow<String> = flow {
        val chatHistory = history.map { msg ->
            if (msg.isUser) {
                content("user") { text(msg.text) }
            } else {
                content("model") { text(msg.text) }
            }
        }

        val dynamicModel = Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content { text(systemPrompt) }
        )
        val chat = dynamicModel.startChat(chatHistory)

        withTimeout(60_000L) {
            chat.sendMessageStream(userMessage).collect { chunk ->
                val chunkText = chunk.text.orEmpty()
                if (chunkText.isNotEmpty()) {
                    emit(chunkText)
                }
            }
        }
    }
}
