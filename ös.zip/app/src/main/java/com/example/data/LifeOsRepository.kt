package com.example.data

import com.example.model.AppReview
import com.example.model.BlockCategory
import com.example.model.ChatMessage
import com.example.model.DailyOsMetrics
import com.example.model.EnergyLevel
import com.example.model.GoalBlueprint
import com.example.model.GoalPhase
import com.example.model.HabitItem
import com.example.model.HealthVitals
import com.example.model.IntelligenceVitals
import com.example.model.NoteItem
import com.example.model.PlanBlock
import com.example.model.Subtask
import com.example.model.TaskItem
import com.example.model.TaskPriority
import com.example.model.UserAchievement
import com.example.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class LifeOsRepository {

    private val _scheduleBlocks = MutableStateFlow<List<PlanBlock>>(
        listOf(
            PlanBlock(
                title = "Morning Launch & Strategy",
                description = "Review top 3 high-leverage outcomes, hydration, and calendar alignment.",
                timeStart = "07:30",
                timeEnd = "08:15",
                category = BlockCategory.ADMIN,
                isCompleted = true,
                energyLevel = EnergyLevel.MODERATE,
                tips = "No email or social feeds before priorities are locked in."
            ),
            PlanBlock(
                title = "Deep Work: Core Architecture",
                description = "Build Gemini AI logic pipeline, App Check integration, and state contracts.",
                timeStart = "08:30",
                timeEnd = "11:00",
                category = BlockCategory.DEEP_WORK,
                isCompleted = true,
                energyLevel = EnergyLevel.HIGH,
                tips = "Phone in Do-Not-Disturb; 90-minute uninterrupted sprint."
            ),
            PlanBlock(
                title = "Team Sync & Code Review",
                description = "Align on product roadmap, user flows, and pull request reviews.",
                timeStart = "11:15",
                timeEnd = "12:00",
                category = BlockCategory.MEETING,
                isCompleted = false,
                energyLevel = EnergyLevel.MODERATE,
                tips = "Keep agenda strictly to blockers and decision-making."
            ),
            PlanBlock(
                title = "Health, Nutrition & Walk",
                description = "High-protein lunch, fresh air, and light sunlight exposure.",
                timeStart = "12:00",
                timeEnd = "13:00",
                category = BlockCategory.HEALTH,
                isCompleted = false,
                energyLevel = EnergyLevel.LOW,
                tips = "Step away from all screens to recharge cognitive capacity."
            ),
            PlanBlock(
                title = "Sprint: UI Polish & Testing",
                description = "Refine interactive animations, button clickability, and accessibility tags.",
                timeStart = "13:30",
                timeEnd = "15:30",
                category = BlockCategory.DEEP_WORK,
                isCompleted = false,
                energyLevel = EnergyLevel.HIGH,
                tips = "Test edge cases on small and large screens."
            ),
            PlanBlock(
                title = "Admin, Inbox & Daily Retro",
                description = "Clear communications, update habit streaks, log focus minutes.",
                timeStart = "16:00",
                timeEnd = "17:00",
                category = BlockCategory.ADMIN,
                isCompleted = false,
                energyLevel = EnergyLevel.LOW,
                tips = "Wrap up loose ends so tomorrow starts completely clean."
            )
        )
    )
    val scheduleBlocks: StateFlow<List<PlanBlock>> = _scheduleBlocks.asStateFlow()

    private val _tasks = MutableStateFlow<List<TaskItem>>(
        listOf(
            TaskItem(
                title = "Finalize LifeOS AI Planner Architecture",
                category = "Engineering",
                priority = TaskPriority.P1_URGENT,
                dueDate = "Today",
                isCompleted = true,
                subtasks = listOf(
                    Subtask(title = "App Check configuration", isCompleted = true),
                    Subtask(title = "Gemini 3.8-flash model wiring", isCompleted = true),
                    Subtask(title = "Structured JSON schema validation", isCompleted = true)
                )
            ),
            TaskItem(
                title = "Design Interactive Focus Mode HUD",
                category = "Design",
                priority = TaskPriority.P1_URGENT,
                dueDate = "Today",
                isCompleted = false,
                subtasks = listOf(
                    Subtask(title = "Pomodoro circular gauge", isCompleted = true),
                    Subtask(title = "Session completion auto-logging", isCompleted = false),
                    Subtask(title = "Ambient sound selector", isCompleted = false)
                )
            ),
            TaskItem(
                title = "Audit Mobile Accessibility & 48dp Touch Targets",
                category = "QA",
                priority = TaskPriority.P2_IMPORTANT,
                dueDate = "Today",
                isCompleted = false,
                subtasks = listOf(
                    Subtask(title = "Add Compose testTags on primary actions", isCompleted = true),
                    Subtask(title = "Verify bottom nav safe insets", isCompleted = false)
                )
            ),
            TaskItem(
                title = "Draft Q4 Strategic Vision & Milestones",
                category = "Strategy",
                priority = TaskPriority.P2_IMPORTANT,
                dueDate = "Tomorrow",
                isCompleted = false
            ),
            TaskItem(
                title = "Review Weekly Habit Streaks & Focus Analytics",
                category = "Habits",
                priority = TaskPriority.P3_ROUTINE,
                dueDate = "This Week",
                isCompleted = false
            )
        )
    )
    val tasks: StateFlow<List<TaskItem>> = _tasks.asStateFlow()

    private val _habits = MutableStateFlow<List<HabitItem>>(
        listOf(
            HabitItem(
                title = "Hydrate 2.5 Liters",
                category = "Health",
                iconKey = "water_drop",
                streak = 14,
                completedToday = true,
                last7Days = listOf(true, true, true, true, true, true, true)
            ),
            HabitItem(
                title = "45m Deep Work Sprint",
                category = "Productivity",
                iconKey = "bolt",
                streak = 9,
                completedToday = true,
                last7Days = listOf(true, false, true, true, true, true, true)
            ),
            HabitItem(
                title = "Read 15 Pages of Book",
                category = "Growth",
                iconKey = "auto_stories",
                streak = 6,
                completedToday = false,
                last7Days = listOf(true, true, true, true, true, false, false)
            ),
            HabitItem(
                title = "Postural Stretch & 10k Steps",
                category = "Health",
                iconKey = "directions_walk",
                streak = 4,
                completedToday = false,
                last7Days = listOf(false, true, true, true, true, false, false)
            ),
            HabitItem(
                title = "Evening Digital Sunset (No Screens)",
                category = "Rest",
                iconKey = "nights_stay",
                streak = 11,
                completedToday = false,
                last7Days = listOf(true, true, true, true, true, true, false)
            )
        )
    )
    val habits: StateFlow<List<HabitItem>> = _habits.asStateFlow()

    private val _notes = MutableStateFlow<List<NoteItem>>(
        listOf(
            NoteItem(
                title = "LifeOS Architecture Principles",
                content = "1. Every button must have clear immediate functional feedback.\n2. AI is an executive copilot, not a generic toy chatbot.\n3. Friction kills momentum: plans must import in one tap.\n4. Design must look cybernetic, high-trust, and ultra-crisp.",
                timestamp = "2 hours ago",
                tags = listOf("Design", "Architecture", "AI"),
                summary = "Core design rules prioritizing one-tap action, frictionless momentum, and clean execution.",
                extractedTasks = listOf(
                    "Ensure 1-tap plan import into timeline",
                    "Verify all button handlers trigger real state updates"
                )
            ),
            NoteItem(
                title = "High Leverage Daily Protocol",
                content = "Peak alertness happens within 2-4 hours post waking. Protect this window ruthlessly. Do not check asynchronous messages before 11:00 AM.",
                timestamp = "Yesterday",
                tags = listOf("Productivity", "Routines"),
                summary = "Safeguard morning cognitive bandwidth by delaying communications until after noon.",
                extractedTasks = listOf(
                    "Block 08:30 to 11:00 AM for non-negotiable deep work"
                )
            )
        )
    )
    val notes: StateFlow<List<NoteItem>> = _notes.asStateFlow()

    private val _savedGoals = MutableStateFlow<List<GoalBlueprint>>(
        listOf(
            GoalBlueprint(
                title = "Build & Ship AI Powered Indie App",
                targetTimeframe = "30 Days",
                summaryStrategy = "Rapid prototyping, validating core AI value, and deploying with zero friction.",
                phases = listOf(
                    GoalPhase(1, "Core Engine & Foundations", "Setup Gemini AI logic, security, and foundational models", listOf("Architecture design", "App Check integration", "Base UI skeleton")),
                    GoalPhase(2, "Feature Complete & Polish", "Build full planner, tasks, timer, and reactive store", listOf("1-tap schedule generation", "Task decomposition", "Focus HUD")),
                    GoalPhase(3, "Testing & User Feedback", "Polish animations, test edge cases, and launch", listOf("Comprehensive UI audit", "Beta user trial", "Store submission"))
                ),
                suggestedDailyHabits = listOf("60m uninterrupted coding block", "Daily commit and progress review"),
                immediateNextAction = "Implement seamless navigation and functional action listeners."
            )
        )
    )
    val savedGoals: StateFlow<List<GoalBlueprint>> = _savedGoals.asStateFlow()

    private val _focusMinutesToday = MutableStateFlow(45)
    val focusMinutesToday: StateFlow<Int> = _focusMinutesToday.asStateFlow()

    private val _userEnergyStatus = MutableStateFlow(EnergyLevel.HIGH)
    val userEnergyStatus: StateFlow<EnergyLevel> = _userEnergyStatus.asStateFlow()

    // ---------------- Actions ---------------- //

    fun togglePlanBlock(blockId: String) {
        _scheduleBlocks.update { list ->
            list.map { if (it.id == blockId) it.copy(isCompleted = !it.isCompleted) else it }
        }
    }

    fun addPlanBlock(block: PlanBlock) {
        _scheduleBlocks.update { (it + block).sortedBy { b -> b.timeStart } }
    }

    fun deletePlanBlock(blockId: String) {
        _scheduleBlocks.update { list -> list.filterNot { it.id == blockId } }
    }

    fun applyAiGeneratedPlan(newBlocks: List<PlanBlock>) {
        _scheduleBlocks.value = newBlocks.sortedBy { it.timeStart }
    }

    fun toggleTask(taskId: String) {
        _tasks.update { list ->
            list.map { if (it.id == taskId) it.copy(isCompleted = !it.isCompleted) else it }
        }
    }

    fun toggleSubtask(taskId: String, subtaskId: String) {
        _tasks.update { list ->
            list.map { task ->
                if (task.id == taskId) {
                    val updatedSubtasks = task.subtasks.map { sub ->
                        if (sub.id == subtaskId) sub.copy(isCompleted = !sub.isCompleted) else sub
                    }
                    task.copy(subtasks = updatedSubtasks)
                } else task
            }
        }
    }

    fun addTask(task: TaskItem) {
        _tasks.update { listOf(task) + it }
    }

    fun deleteTask(taskId: String) {
        _tasks.update { list -> list.filterNot { it.id == taskId } }
    }

    fun addSubtasksToTask(taskId: String, subtaskTitles: List<String>) {
        _tasks.update { list ->
            list.map { task ->
                if (task.id == taskId) {
                    val newSubs = subtaskTitles.map { Subtask(title = it) }
                    task.copy(subtasks = task.subtasks + newSubs)
                } else task
            }
        }
    }

    fun toggleHabit(habitId: String) {
        _habits.update { list ->
            list.map { habit ->
                if (habit.id == habitId) {
                    val nextCompleted = !habit.completedToday
                    val nextStreak = if (nextCompleted) habit.streak + 1 else maxOf(0, habit.streak - 1)
                    habit.copy(completedToday = nextCompleted, streak = nextStreak)
                } else habit
            }
        }
    }

    fun addHabit(habit: HabitItem) {
        _habits.update { it + habit }
    }

    fun deleteHabit(habitId: String) {
        _habits.update { list -> list.filterNot { it.id == habitId } }
    }

    fun addNote(note: NoteItem) {
        _notes.update { listOf(note) + it }
    }

    fun deleteNote(noteId: String) {
        _notes.update { list -> list.filterNot { it.id == noteId } }
    }

    fun updateNoteSummaryAndTasks(noteId: String, summary: String, tasks: List<String>) {
        _notes.update { list ->
            list.map { if (it.id == noteId) it.copy(summary = summary, extractedTasks = tasks) else it }
        }
    }

    fun logFocusSession(minutes: Int) {
        _focusMinutesToday.update { it + minutes }
    }

    fun setUserEnergy(energy: EnergyLevel) {
        _userEnergyStatus.value = energy
    }

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _healthVitals = MutableStateFlow(HealthVitals())
    val healthVitals: StateFlow<HealthVitals> = _healthVitals.asStateFlow()

    private val _intelligenceVitals = MutableStateFlow(IntelligenceVitals())
    val intelligenceVitals: StateFlow<IntelligenceVitals> = _intelligenceVitals.asStateFlow()

    fun updateHealthVitals(sleep: Float, sport: Int, steps: Int) {
        _healthVitals.update {
            it.copy(
                sleepHours = sleep,
                sleepScore = ((sleep / 8f) * 10).toInt().coerceIn(0, 10),
                sportScore = sport.coerceIn(0, 10),
                stepsToday = steps
            )
        }
    }

    fun updateIntelligenceVitals(iq: Int, eq: Int, sq: Int, pq: Int) {
        _intelligenceVitals.update {
            it.copy(
                iqScore = iq,
                eqScore = eq,
                sqScore = sq,
                pqScore = pq
            )
        }
    }

    private val _userAchievements = MutableStateFlow(
        listOf(
            UserAchievement(title = "14-Day Momentum", description = "Maintained unbroken daily habits for 2 consecutive weeks", emoji = "🔥", isUnlocked = true, unlockedDate = "2 days ago"),
            UserAchievement(title = "Deep Focus Master", description = "Logged over 100 deep work sprints with zero distraction", emoji = "⚡", isUnlocked = true, unlockedDate = "Yesterday"),
            UserAchievement(title = "Strategic Architect", description = "Decomposed 10 complex goals into daily execution phases", emoji = "🎯", isUnlocked = true, unlockedDate = "Last week"),
            UserAchievement(title = "Second Brain Vault", description = "Captured and extracted 25+ insights into concrete tasks", emoji = "🧠", isUnlocked = true, unlockedDate = "5 days ago"),
            UserAchievement(title = "Early Bird 7AM", description = "Started first deep block before 08:00 AM for 7 days", emoji = "🌅", isUnlocked = true, unlockedDate = "Today"),
            UserAchievement(title = "Zen Equilibrium", description = "Maintained 95%+ energy score across high-pressure deliverables", emoji = "🧘", isUnlocked = false, unlockedDate = "Locked")
        )
    )
    val userAchievements: StateFlow<List<UserAchievement>> = _userAchievements.asStateFlow()

    private val _appReviews = MutableStateFlow(
        listOf(
            AppReview(author = "Elena Rostova", rating = 5, comment = "The AI time-blocking is revolutionary. Literally doubled my deep work output.", timeAgo = "Yesterday"),
            AppReview(author = "David Chen", rating = 5, comment = "Clean, beautiful white and blue design. Gemini planning gives me instant clarity every morning.", timeAgo = "3 days ago"),
            AppReview(author = "Sarah Jenkins", rating = 5, comment = "The task decomposition feature is magic. Breaks scary projects into easy micro-steps.", timeAgo = "1 week ago")
        )
    )
    val appReviews: StateFlow<List<AppReview>> = _appReviews.asStateFlow()

    fun updateUserProfile(name: String, title: String) {
        _userProfile.update { it.copy(name = name, title = title) }
    }

    fun submitAppReview(rating: Int, comment: String) {
        val review = AppReview(
            author = _userProfile.value.name,
            rating = rating,
            comment = comment,
            timeAgo = "Just now"
        )
        _appReviews.update { listOf(review) + it }
        val allRatings = _appReviews.value.map { it.rating }
        val newAvg = (allRatings.sum().toFloat() / allRatings.size)
        _userProfile.update { it.copy(overallRating = (Math.round(newAvg * 100) / 100f), totalReviews = it.totalReviews + 1) }
    }

    private val _racers = MutableStateFlow<List<com.example.model.Racer>>(
        listOf(
            com.example.model.Racer(rank = 1, name = "Alex M.", avatarEmoji = "🚀", xp = 4820, focusHours = 18.5f, tasksDone = 32, streakDays = 19, isCurrentUser = false, league = "Diamond", statusBadge = "Leader 👑"),
            com.example.model.Racer(rank = 2, name = "Damir", avatarEmoji = "⚡", xp = 4350, focusHours = 14.5f, tasksDone = 24, streakDays = 14, isCurrentUser = true, league = "Diamond", statusBadge = "Promoting 🥈"),
            com.example.model.Racer(rank = 3, name = "Elena R.", avatarEmoji = "🌟", xp = 4190, focusHours = 13.0f, tasksDone = 28, streakDays = 12, isCurrentUser = false, league = "Diamond", statusBadge = "Promoting 🥉"),
            com.example.model.Racer(rank = 4, name = "David C.", avatarEmoji = "💡", xp = 3840, focusHours = 11.5f, tasksDone = 21, streakDays = 9, isCurrentUser = false, league = "Diamond", statusBadge = "Safe Zone"),
            com.example.model.Racer(rank = 5, name = "Sarah J.", avatarEmoji = "🎯", xp = 3620, focusHours = 10.0f, tasksDone = 19, streakDays = 11, isCurrentUser = false, league = "Diamond", statusBadge = "Safe Zone"),
            com.example.model.Racer(rank = 6, name = "Marcus T.", avatarEmoji = "🔥", xp = 3250, focusHours = 8.5f, tasksDone = 16, streakDays = 8, isCurrentUser = false, league = "Diamond", statusBadge = "Safe Zone"),
            com.example.model.Racer(rank = 7, name = "Yuki S.", avatarEmoji = "🧘", xp = 2980, focusHours = 7.0f, tasksDone = 14, streakDays = 6, isCurrentUser = false, league = "Diamond", statusBadge = "Relegation Zone"),
            com.example.model.Racer(rank = 8, name = "Leo K.", avatarEmoji = "⏱️", xp = 2740, focusHours = 6.2f, tasksDone = 12, streakDays = 5, isCurrentUser = false, league = "Diamond", statusBadge = "Relegation Zone")
        )
    )
    val racers: StateFlow<List<com.example.model.Racer>> = _racers.asStateFlow()

    fun addXpToCurrentUser(xpGain: Int, additionalTasks: Int = 0, additionalFocusHours: Float = 0f) {
        _userProfile.update {
            val newXp = it.xpCurrent + xpGain
            val newLevel = (newXp / 500) + 1
            it.copy(xpCurrent = newXp, level = newLevel)
        }
        _racers.update { currentRacers ->
            val updated = currentRacers.map { racer ->
                if (racer.isCurrentUser) {
                    racer.copy(
                        xp = racer.xp + xpGain,
                        tasksDone = racer.tasksDone + additionalTasks,
                        focusHours = racer.focusHours + additionalFocusHours
                    )
                } else racer
            }
            // Re-sort by XP descending and re-assign ranks
            updated.sortedByDescending { it.xp }.mapIndexed { index, racer ->
                val rank = index + 1
                val badge = when (rank) {
                    1 -> "Leader 👑"
                    2, 3 -> "Promoting 🏆"
                    in 4..6 -> "Safe Zone"
                    else -> "Relegation Zone"
                }
                racer.copy(rank = rank, statusBadge = badge)
            }
        }
    }

    fun saveGoal(goal: GoalBlueprint) {
        _savedGoals.update { listOf(goal) + it }
        // Also automatically add suggested habits to the habit tracker
        if (goal.suggestedDailyHabits.isNotEmpty()) {
            val newHabits = goal.suggestedDailyHabits.map { title ->
                HabitItem(
                    title = title,
                    category = "Goal: ${goal.title.take(15)}...",
                    iconKey = "flag",
                    streak = 0
                )
            }
            _habits.update { it + newHabits }
        }
    }
}
