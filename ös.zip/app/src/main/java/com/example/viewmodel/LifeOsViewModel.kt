package com.example.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AiRepository
import com.example.data.LifeOsRepository
import com.example.model.AppReview
import com.example.model.ChatMessage
import com.example.model.ChatPersona
import com.example.model.DailyOsMetrics
import com.example.model.EnergyLevel
import com.example.model.GoalBlueprint
import com.example.model.HabitItem
import com.example.model.HealthVitals
import com.example.model.IntelligenceVitals
import com.example.model.NoteItem
import com.example.model.PlanBlock
import com.example.model.TaskItem
import com.example.model.UserAchievement
import com.example.model.UserProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "LifeOsViewModel"

enum class OsScreen(val title: String) {
    DASHBOARD("Command Center"),
    AI_PLANNER("AI Planner"),
    ANALYTICS("Analytics"),
    AI_CHAT("AI Copilot"),
    TASKS("Tasks Matrix"),
    FOCUS_TIMER("Focus Engine"),
    NOTES("Second Brain"),
    LEADERBOARD("League Race"),
    USER_PAGE("Performance & Rating"),
    SETTINGS("OS Settings")
}

sealed interface AiPlannerUiState {
    data object Idle : AiPlannerUiState
    data object Loading : AiPlannerUiState
    data class Success(val summary: String, val blocks: List<PlanBlock>) : AiPlannerUiState
    data class Error(val message: String) : AiPlannerUiState
}

sealed interface AiGoalUiState {
    data object Idle : AiGoalUiState
    data object Loading : AiGoalUiState
    data class Success(val blueprint: GoalBlueprint) : AiGoalUiState
    data class Error(val message: String) : AiGoalUiState
}

enum class TimerMode(val label: String, val durationMinutes: Int) {
    DEEP_WORK("Deep Work", 50),
    POMODORO("Focus", 25),
    SHORT_BREAK("Short Break", 5),
    LONG_BREAK("Long Break", 15)
}

enum class TimerStatus {
    STOPPED,
    RUNNING,
    PAUSED
}

class LifeOsViewModel(
    private val lifeOsRepository: LifeOsRepository = LifeOsRepository(),
    private val aiRepository: AiRepository = AiRepository()
) : ViewModel() {

    // Current Screen
    private val _currentScreen = MutableStateFlow(OsScreen.DASHBOARD)
    val currentScreen: StateFlow<OsScreen> = _currentScreen.asStateFlow()

    // Transient User Feedback messages (Toasts / Snackbars)
    private val _userEvents = MutableSharedFlow<String>()
    val userEvents: SharedFlow<String> = _userEvents.asSharedFlow()

    // Core Data flows
    val scheduleBlocks: StateFlow<List<PlanBlock>> = lifeOsRepository.scheduleBlocks
    val tasks: StateFlow<List<TaskItem>> = lifeOsRepository.tasks
    val habits: StateFlow<List<HabitItem>> = lifeOsRepository.habits
    val notes: StateFlow<List<NoteItem>> = lifeOsRepository.notes
    val savedGoals: StateFlow<List<GoalBlueprint>> = lifeOsRepository.savedGoals
    val focusMinutesToday: StateFlow<Int> = lifeOsRepository.focusMinutesToday
    val userEnergyStatus: StateFlow<EnergyLevel> = lifeOsRepository.userEnergyStatus

    // User Profile, Performance & Leaderboard Data
    val userProfile: StateFlow<UserProfile> = lifeOsRepository.userProfile
    val healthVitals: StateFlow<HealthVitals> = lifeOsRepository.healthVitals
    val intelligenceVitals: StateFlow<IntelligenceVitals> = lifeOsRepository.intelligenceVitals
    val userAchievements: StateFlow<List<UserAchievement>> = lifeOsRepository.userAchievements
    val appReviews: StateFlow<List<AppReview>> = lifeOsRepository.appReviews
    val racers: StateFlow<List<com.example.model.Racer>> = lifeOsRepository.racers

    fun boostRaceXp(xp: Int, reason: String) {
        lifeOsRepository.addXpToCurrentUser(xp)
        viewModelScope.launch {
            _userEvents.emit("⚡ +$xp XP earned: $reason! Leaderboard position boosted.")
        }
    }

    fun updateHealthVitals(sleep: Float, sport: Int, steps: Int) {
        lifeOsRepository.updateHealthVitals(sleep, sport, steps)
    }

    fun updateIntelligenceVitals(iq: Int, eq: Int, sq: Int, pq: Int) {
        lifeOsRepository.updateIntelligenceVitals(iq, eq, sq, pq)
    }

    // Daily Metrics computed state
    val dailyMetrics: StateFlow<DailyOsMetrics> = combine(
        tasks,
        habits,
        focusMinutesToday
    ) { currentTasks, currentHabits, minutes ->
        DailyOsMetrics(
            tasksCompleted = currentTasks.count { it.isCompleted },
            totalTasks = currentTasks.size,
            focusMinutesLogged = minutes,
            habitsCompleted = currentHabits.count { it.completedToday },
            totalHabits = currentHabits.size,
            energyScore = if (minutes > 60) 95 else 82
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DailyOsMetrics(1, 5, 45, 2, 5, 85)
    )

    // AI Planning state
    private val _plannerState = MutableStateFlow<AiPlannerUiState>(AiPlannerUiState.Idle)
    val plannerState: StateFlow<AiPlannerUiState> = _plannerState.asStateFlow()

    // AI Goal state
    private val _goalState = MutableStateFlow<AiGoalUiState>(AiGoalUiState.Idle)
    val goalState: StateFlow<AiGoalUiState> = _goalState.asStateFlow()

    // AI Chat Personas
    val chatPersonas = listOf(
        ChatPersona(
            id = "strategist",
            name = "Strategic Coach",
            emoji = "⚡",
            tagline = "High-leverage time blocking & priority execution",
            systemPrompt = "You are the ÖS Strategic Copilot. You are an expert high-performance executive coach. Provide crisp, directly actionable advice, prioritize tasks, challenge distractions, and formulate clear daily momentum routines."
        ),
        ChatPersona(
            id = "mentor",
            name = "Mindful Mentor",
            emoji = "🧘",
            tagline = "Cognitive clarity, flow state & stress reduction",
            systemPrompt = "You are the ÖS Mindful Mentor. Help the user maintain calm focus, navigate overwhelm, build sustainable recovery rituals, and balance energy levels with practical grounding steps."
        ),
        ChatPersona(
            id = "architect",
            name = "System Architect",
            emoji = "🎯",
            tagline = "Technical problem-solving & roadmap breakdown",
            systemPrompt = "You are the ÖS System Architect. Break down complex software, engineering, and business problems into clear technical roadmaps, milestones, and granular execution steps."
        )
    )

    private val _selectedPersona = MutableStateFlow(chatPersonas.first())
    val selectedPersona: StateFlow<ChatPersona> = _selectedPersona.asStateFlow()

    // AI Copilot Chat state
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                isUser = false,
                text = "Welcome to **ÖS Strategic Copilot**. Powered by Gemini 3.8-flash.\n\nI can analyze your schedule, formulate deep work strategies, troubleshoot focus bottlenecks, or decompose complex goals. How can I assist you right now?"
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isChatGenerating = MutableStateFlow(false)
    val isChatGenerating: StateFlow<Boolean> = _isChatGenerating.asStateFlow()

    // Active Task decompose state (taskId -> isLoading)
    private val _decomposingTaskId = MutableStateFlow<String?>(null)
    val decomposingTaskId: StateFlow<String?> = _decomposingTaskId.asStateFlow()

    // Active Note summarize state (noteId -> isLoading)
    private val _summarizingNoteId = MutableStateFlow<String?>(null)
    val summarizingNoteId: StateFlow<String?> = _summarizingNoteId.asStateFlow()

    // Focus Timer State
    private val _timerMode = MutableStateFlow(TimerMode.POMODORO)
    val timerMode: StateFlow<TimerMode> = _timerMode.asStateFlow()

    private val _timerSecondsLeft = MutableStateFlow(TimerMode.POMODORO.durationMinutes * 60)
    val timerSecondsLeft: StateFlow<Int> = _timerSecondsLeft.asStateFlow()

    private val _timerStatus = MutableStateFlow(TimerStatus.STOPPED)
    val timerStatus: StateFlow<TimerStatus> = _timerStatus.asStateFlow()

    private var timerJob: Job? = null

    // Navigation
    fun navigateTo(screen: OsScreen) {
        _currentScreen.value = screen
    }

    fun selectChatPersona(persona: ChatPersona) {
        _selectedPersona.value = persona
        _chatMessages.value = _chatMessages.value + ChatMessage(
            isUser = false,
            text = "${persona.emoji} Switched persona to **${persona.name}** mode.\n*${persona.tagline}*. What is on your mind?"
        )
    }

    fun clearChatHistory() {
        val p = _selectedPersona.value
        _chatMessages.value = listOf(
            ChatMessage(
                isUser = false,
                text = "${p.emoji} Memory cleared. I'm ready to help you plan, optimize focus, or execute your goals!"
            )
        )
        viewModelScope.launch {
            _userEvents.emit("Chat thread refreshed")
        }
    }

    // ---------------- User Profile & Rating Actions ---------------- //

    fun updateUserProfile(name: String, title: String) {
        lifeOsRepository.updateUserProfile(name, title)
        viewModelScope.launch {
            _userEvents.emit("Profile updated successfully!")
        }
    }

    fun submitAppReview(rating: Int, comment: String) {
        lifeOsRepository.submitAppReview(rating, comment)
        viewModelScope.launch {
            _userEvents.emit("Thank you! Review submitted with $rating ★ rating.")
        }
    }

    // ---------------- AI Features ---------------- //

    fun generateDailyPlan(
        userPrompt: String,
        wakeTime: String = "07:30",
        sleepTime: String = "23:00",
        hoursDeepWork: Int = 4,
        energyPeak: String = "Morning"
    ) {
        if (userPrompt.isBlank()) return
        viewModelScope.launch {
            _plannerState.value = AiPlannerUiState.Loading
            try {
                val (summary, blocks) = aiRepository.generateDailyPlan(
                    userPrompt = userPrompt,
                    wakeTime = wakeTime,
                    sleepTime = sleepTime,
                    hoursDeepWork = hoursDeepWork,
                    energyPeak = energyPeak
                )
                _plannerState.value = AiPlannerUiState.Success(summary, blocks)
                _userEvents.emit("Gemini generated ${blocks.size} time blocks!")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Plan generation error", e)
                _plannerState.value = AiPlannerUiState.Error(
                    e.localizedMessage ?: "Failed to generate plan. Please try again."
                )
            }
        }
    }

    fun applyPlanToToday() {
        val state = _plannerState.value
        if (state is AiPlannerUiState.Success) {
            lifeOsRepository.applyAiGeneratedPlan(state.blocks)
            viewModelScope.launch {
                _userEvents.emit("Applied plan to Today's Timeline!")
            }
            _plannerState.value = AiPlannerUiState.Idle
            _currentScreen.value = OsScreen.DASHBOARD
        }
    }

    fun generateGoalBlueprint(goalPrompt: String, timeframe: String) {
        if (goalPrompt.isBlank()) return
        viewModelScope.launch {
            _goalState.value = AiGoalUiState.Loading
            try {
                val blueprint = aiRepository.breakdownGoal(goalPrompt, timeframe)
                _goalState.value = AiGoalUiState.Success(blueprint)
                _userEvents.emit("Goal blueprint generated with ${blueprint.phases.size} phases!")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Goal blueprint error", e)
                _goalState.value = AiGoalUiState.Error(
                    e.localizedMessage ?: "Failed to decompose goal."
                )
            }
        }
    }

    fun saveGoalToLifeOs(blueprint: GoalBlueprint) {
        lifeOsRepository.saveGoal(blueprint)
        viewModelScope.launch {
            _userEvents.emit("Goal & habits saved to ÖS!")
        }
        _goalState.value = AiGoalUiState.Idle
    }

    fun decomposeTask(task: TaskItem) {
        viewModelScope.launch {
            _decomposingTaskId.value = task.id
            try {
                val subtasks = aiRepository.decomposeTask(task.title)
                lifeOsRepository.addSubtasksToTask(task.id, subtasks)
                _userEvents.emit("Decomposed into ${subtasks.size} executable subtasks!")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Task decomposition error", e)
                _userEvents.emit("Could not decompose task: ${e.localizedMessage}")
            } finally {
                _decomposingTaskId.value = null
            }
        }
    }

    fun summarizeAndExtractNote(note: NoteItem) {
        viewModelScope.launch {
            _summarizingNoteId.value = note.id
            try {
                val (summary, extracted) = aiRepository.summarizeAndExtract(note.title, note.content)
                lifeOsRepository.updateNoteSummaryAndTasks(note.id, summary, extracted)
                _userEvents.emit("Extracted ${extracted.size} action tasks from note!")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Note summarize error", e)
                _userEvents.emit("Note analysis failed: ${e.localizedMessage}")
            } finally {
                _summarizingNoteId.value = null
            }
        }
    }

    fun convertExtractedTasksToMainTasks(tasks: List<String>, category: String = "Second Brain") {
        tasks.forEach { title ->
            lifeOsRepository.addTask(
                TaskItem(
                    title = title,
                    category = category,
                    aiSuggested = true
                )
            )
        }
        viewModelScope.launch {
            _userEvents.emit("Added ${tasks.size} action items to Tasks Matrix!")
        }
    }

    fun sendChatMessage(text: String) {
        if (text.isBlank() || _isChatGenerating.value) return
        val userMsg = ChatMessage(isUser = true, text = text)
        _chatMessages.value = _chatMessages.value + userMsg
        _isChatGenerating.value = true

        viewModelScope.launch {
            val responseBuilder = StringBuilder()
            val botMsgId = java.util.UUID.randomUUID().toString()
            val initialBotMsg = ChatMessage(id = botMsgId, isUser = false, text = "...")
            _chatMessages.value = _chatMessages.value + initialBotMsg

            try {
                val history = _chatMessages.value.dropLast(2)
                aiRepository.chatStream(
                    userMessage = text,
                    history = history,
                    systemPrompt = _selectedPersona.value.systemPrompt
                ).collect { chunk ->
                    responseBuilder.append(chunk)
                    _chatMessages.value = _chatMessages.value.map {
                        if (it.id == botMsgId) it.copy(text = responseBuilder.toString()) else it
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Chat streaming error", e)
                _chatMessages.value = _chatMessages.value.map {
                    if (it.id == botMsgId) it.copy(
                        text = "I encountered an issue processing that: ${e.localizedMessage ?: "Unknown error"}. Please tap retry or ask another question."
                    ) else it
                }
            } finally {
                _isChatGenerating.value = false
            }
        }
    }

    // ---------------- Focus Timer ---------------- //

    fun setTimerMode(mode: TimerMode) {
        timerJob?.cancel()
        _timerMode.value = mode
        _timerSecondsLeft.value = mode.durationMinutes * 60
        _timerStatus.value = TimerStatus.STOPPED
    }

    fun startTimer() {
        if (_timerStatus.value == TimerStatus.RUNNING) return
        _timerStatus.value = TimerStatus.RUNNING
        timerJob = viewModelScope.launch {
            while (_timerSecondsLeft.value > 0 && _timerStatus.value == TimerStatus.RUNNING) {
                delay(1000L)
                _timerSecondsLeft.value = _timerSecondsLeft.value - 1
            }
            if (_timerSecondsLeft.value <= 0) {
                _timerStatus.value = TimerStatus.STOPPED
                val minutesCompleted = _timerMode.value.durationMinutes
                lifeOsRepository.logFocusSession(minutesCompleted)
                val xpEarned = minutesCompleted * 2
                lifeOsRepository.addXpToCurrentUser(xpEarned, 0, minutesCompleted / 60f)
                _userEvents.emit("🎉 Great focus! +$xpEarned XP logged to your Leaderboard race.")
                _timerSecondsLeft.value = _timerMode.value.durationMinutes * 60
            }
        }
    }

    fun pauseTimer() {
        _timerStatus.value = TimerStatus.PAUSED
        timerJob?.cancel()
    }

    fun resetTimer() {
        timerJob?.cancel()
        _timerStatus.value = TimerStatus.STOPPED
        _timerSecondsLeft.value = _timerMode.value.durationMinutes * 60
    }

    // ---------------- CRUD Actions ---------------- //

    fun togglePlanBlock(blockId: String) = lifeOsRepository.togglePlanBlock(blockId)
    fun addPlanBlock(block: PlanBlock) = lifeOsRepository.addPlanBlock(block)
    fun deletePlanBlock(blockId: String) = lifeOsRepository.deletePlanBlock(blockId)

    fun toggleTask(taskId: String) {
        val task = tasks.value.find { it.id == taskId }
        val willBeCompleted = task != null && !task.isCompleted
        lifeOsRepository.toggleTask(taskId)
        if (willBeCompleted) {
            lifeOsRepository.addXpToCurrentUser(50, 1, 0f)
            viewModelScope.launch {
                _userEvents.emit("⚡ Task completed! +50 XP added to Leaderboard.")
            }
        }
    }
    fun toggleSubtask(taskId: String, subtaskId: String) = lifeOsRepository.toggleSubtask(taskId, subtaskId)
    fun addTask(task: TaskItem) = lifeOsRepository.addTask(task)
    fun deleteTask(taskId: String) = lifeOsRepository.deleteTask(taskId)

    fun toggleHabit(habitId: String) = lifeOsRepository.toggleHabit(habitId)
    fun addHabit(habit: HabitItem) = lifeOsRepository.addHabit(habit)
    fun deleteHabit(habitId: String) = lifeOsRepository.deleteHabit(habitId)

    fun addNote(note: NoteItem) = lifeOsRepository.addNote(note)
    fun deleteNote(noteId: String) = lifeOsRepository.deleteNote(noteId)

    fun setUserEnergy(energy: EnergyLevel) = lifeOsRepository.setUserEnergy(energy)
}
