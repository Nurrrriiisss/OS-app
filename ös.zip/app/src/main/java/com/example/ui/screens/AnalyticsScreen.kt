package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.HealthVitals
import com.example.model.IntelligenceVitals
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.LifeOsViewModel
import com.example.viewmodel.OsScreen

@Composable
fun AnalyticsScreen(
    viewModel: LifeOsViewModel,
    modifier: Modifier = Modifier
) {
    val healthVitals by viewModel.healthVitals.collectAsState()
    val intelligenceVitals by viewModel.intelligenceVitals.collectAsState()
    val metrics by viewModel.dailyMetrics.collectAsState()

    var selectedPeriodIndex by remember { mutableIntStateOf(1) } // 0: Day, 1: Week, 2: Month
    val periods = listOf("Day", "Week", "Month")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhite)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Header with Back Button & Time Period Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(OsScreen.DASHBOARD) },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SurfaceWhite)
                            .border(1.dp, BorderLight, CircleShape)
                            .testTag("analytics_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Analytics & Body Vitals",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Physical Condition & Intelligence Telemetry",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Period Selector
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(SurfaceWhite)
                        .border(1.dp, BorderLight, RoundedCornerShape(20.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    periods.forEachIndexed { idx, p ->
                        val isSel = idx == selectedPeriodIndex
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSel) BrandBlue else Color.Transparent)
                                .clickable { selectedPeriodIndex = idx }
                                .padding(horizontal = 9.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = p,
                                color = if (isSel) Color.White else TextMuted,
                                fontSize = 11.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // 2. The Signature Body Analysis Section (Front & Back Anatomical Silhouettes + Health & Intelligence Cards)
        item {
            AnalyticsBodySection(
                healthVitals = healthVitals,
                intelligenceVitals = intelligenceVitals
            )
        }

        // 3. Equilibrium Balance Metric Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Equilibrium Index",
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Mind & Body Harmonization",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(BrandBlueSubtle)
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "OPTIMAL 92%",
                                color = BrandBlueDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AnalyticsQuickTile(
                            icon = Icons.Default.DirectionsRun,
                            label = "Physical",
                            score = "${healthVitals.overallScore}/10",
                            accentColor = SuccessGreen,
                            modifier = Modifier.weight(1f)
                        )
                        AnalyticsQuickTile(
                            icon = Icons.Default.Psychology,
                            label = "Mental",
                            score = "${intelligenceVitals.overallScore}/10",
                            accentColor = BrandBlue,
                            modifier = Modifier.weight(1f)
                        )
                        AnalyticsQuickTile(
                            icon = Icons.Default.Timer,
                            label = "Deep Work",
                            score = "${metrics.focusMinutesLogged}m",
                            accentColor = WarningAmber,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 4. Daily Focus Stamina Trends Chart
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Focus Velocity Trends",
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text("Target: 120m/day", color = BrandBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    val focusCurve = listOf(
                        Pair("Mon", 140),
                        Pair("Tue", 185),
                        Pair("Wed", 110),
                        Pair("Thu", 195),
                        Pair("Fri", 160),
                        Pair("Sat", 90),
                        Pair("Sun", 125)
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(95.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        focusCurve.forEach { (day, mins) ->
                            val isAboveGoal = mins >= 120
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = "${mins}m",
                                    color = if (isAboveGoal) BrandBlueDark else TextTertiary,
                                    fontSize = 9.sp,
                                    fontWeight = if (isAboveGoal) FontWeight.Bold else FontWeight.Normal
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Box(
                                    modifier = Modifier
                                        .width(16.dp)
                                        .height((mins * 0.35f).dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isAboveGoal) BrandBlue else BrandBlueSubtle)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = day,
                                    color = if (isAboveGoal) TextPrimary else TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = if (isAboveGoal) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Body analysis section featuring dual anatomical silhouettes and Health + Intelligence cards.
 */
@Composable
private fun AnalyticsBodySection(
    healthVitals: HealthVitals,
    intelligenceVitals: IntelligenceVitals
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top
    ) {
        // Left Column: Front and Back Body Anatomical Silhouettes from Reference
        Card(
            modifier = Modifier
                .width(136.dp)
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
            shape = RoundedCornerShape(16.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp, horizontal = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Front Body View
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("FRONT BODY", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Image(
                        painter = painterResource(id = R.drawable.body_front),
                        contentDescription = "Front Body Silhouette",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(185.dp)
                    )
                }

                Box(modifier = Modifier.fillMaxWidth(0.85f).height(1.dp).background(BorderLight))

                // Back Body View
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("BACK BODY", color = TextTertiary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Image(
                        painter = painterResource(id = R.drawable.body_back),
                        contentDescription = "Back Body Silhouette",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(185.dp)
                    )
                }
            }
        }

        // Right Column: Health & Intelligence Cards
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Health Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE8F5E9)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = null,
                                    tint = SuccessGreen,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Health",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFE8F5E9))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${healthVitals.overallScore}/10",
                                color = SuccessGreen,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    RpgStatItem(
                        icon = Icons.Default.NightsStay,
                        iconTint = Color(0xFF6366F1),
                        label = "Sleep",
                        subtext = "${healthVitals.sleepScore}/10",
                        progress = (healthVitals.sleepScore / 10f).coerceIn(0f, 1f),
                        progressColor = Color(0xFF6366F1)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    RpgStatItem(
                        icon = Icons.Default.DirectionsRun,
                        iconTint = SuccessGreen,
                        label = "Sport",
                        subtext = "${healthVitals.sportScore}/10",
                        progress = (healthVitals.sportScore / 10f).coerceIn(0f, 1f),
                        progressColor = SuccessGreen
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    RpgStatItem(
                        icon = Icons.Default.FavoriteBorder,
                        iconTint = WarningAmber,
                        label = "Steps",
                        subtext = "${healthVitals.stepsToday} / day",
                        progress = (healthVitals.stepsToday.toFloat() / healthVitals.stepsTarget).coerceIn(0f, 1f),
                        progressColor = WarningAmber
                    )
                }
            }

            // Intelligence Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(BrandBlueSubtle),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = BrandBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Intelligence",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFFEDE9FE))
                                .padding(horizontal = 7.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${intelligenceVitals.overallScore}/10",
                                color = Color(0xFF6D28D9),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    RpgStatItem(
                        icon = Icons.Default.Psychology,
                        iconTint = BrandBlue,
                        label = "IQ",
                        subtext = "${intelligenceVitals.iqScore}/10",
                        progress = (intelligenceVitals.iqScore / 10f).coerceIn(0f, 1f),
                        progressColor = BrandBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    RpgStatItem(
                        icon = Icons.Default.FavoriteBorder,
                        iconTint = SuccessGreen,
                        label = "EQ",
                        subtext = "${intelligenceVitals.eqScore}/100",
                        progress = (intelligenceVitals.eqScore / 100f).coerceIn(0f, 1f),
                        progressColor = SuccessGreen
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    RpgStatItem(
                        icon = Icons.Default.SelfImprovement,
                        iconTint = Color(0xFF8B5CF6),
                        label = "SQ",
                        subtext = "${intelligenceVitals.sqScore}/100",
                        progress = (intelligenceVitals.sqScore / 100f).coerceIn(0f, 1f),
                        progressColor = Color(0xFF8B5CF6)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    RpgStatItem(
                        icon = Icons.Default.Star,
                        iconTint = WarningAmber,
                        label = "PQ",
                        subtext = "${intelligenceVitals.pqScore}/100",
                        progress = (intelligenceVitals.pqScore / 100f).coerceIn(0f, 1f),
                        progressColor = WarningAmber
                    )
                }
            }
        }
    }
}

@Composable
private fun RpgStatItem(
    icon: ImageVector,
    iconTint: Color,
    label: String,
    subtext: String,
    progress: Float,
    progressColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(iconTint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = iconTint,
                modifier = Modifier.size(13.dp)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = label, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = subtext, color = TextMuted, fontSize = 10.sp)
            }
            Spacer(modifier = Modifier.height(2.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape),
                color = progressColor,
                trackColor = Color(0xFFF1F5F9)
            )
        }
    }
}

@Composable
private fun AnalyticsQuickTile(
    icon: ImageVector,
    label: String,
    score: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(OffWhite)
            .border(1.dp, BorderLight, RoundedCornerShape(12.dp))
            .padding(vertical = 10.dp, horizontal = 6.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = score, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = label, color = TextMuted, fontSize = 10.sp, maxLines = 1)
        }
    }
}
