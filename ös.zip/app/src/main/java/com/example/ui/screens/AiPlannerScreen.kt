package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ChatMessage
import com.example.model.GoalBlueprint
import com.example.model.PlanBlock
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueBorder
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AiGoalUiState
import com.example.viewmodel.AiPlannerUiState
import com.example.viewmodel.LifeOsViewModel

@Composable
fun AiPlannerScreen(
    viewModel: LifeOsViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Daily Schedule", "Goal Architect")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhite)
    ) {
        // Top Header with ÖS Logo
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            shape = RoundedCornerShape(14.dp),
            border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BrandBlueBorder, BorderLight)))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.os_logo),
                        contentDescription = "ÖS",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ÖS Strategic Planner",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Powered by Gemini 3.8 Flash",
                            color = BrandBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(BrandBlueSubtle, RoundedCornerShape(8.dp))
                        .border(1.dp, BrandBlueBorder, RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("ACTIVE", color = BrandBlueDark, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // White & Blue Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = SurfaceWhite,
            contentColor = BrandBlue,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = BrandBlue,
                    height = 3.dp
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    modifier = Modifier.testTag("planner_tab_$index"),
                    text = {
                        Text(
                            text = title,
                            color = if (selectedTab == index) BrandBlue else TextMuted,
                            fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            when (selectedTab) {
                0 -> DailyScheduleTab(viewModel)
                1 -> GoalArchitectTab(viewModel)
            }
        }
    }
}

// ----------------- TAB 1: Daily Schedule Builder ----------------- //

@Composable
private fun DailyScheduleTab(viewModel: LifeOsViewModel) {
    val plannerState by viewModel.plannerState.collectAsState()

    var userFocus by remember {
        mutableStateOf("Ship ÖS white & blue UI update, deep work on features, 45m workout at 6pm, review release goals")
    }
    var wakeTime by remember { mutableStateOf("07:30") }
    var sleepTime by remember { mutableStateOf("23:00") }
    var deepWorkHours by remember { mutableIntStateOf(4) }
    var energyPeak by remember { mutableStateOf("Morning") }

    val presetPrompts = listOf(
        "⚡ 6h Deep Focus & High Leverage",
        "🎯 Balanced Sprint: Work, Gym & 1h Study",
        "🚀 Launch Day: Fast execution & team sync",
        "📚 Study Marathon & Coding Mastery"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(listOf(BrandBlueBorder, BorderLight))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Today's Core Focus & Intentions",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Describe your goals and appointments. Gemini will build an optimized time-blocked schedule.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = userFocus,
                        onValueChange = { userFocus = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("ai_prompt_input"),
                        placeholder = { Text("Enter your focus items here...", color = TextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = BorderLight,
                            focusedContainerColor = OffWhite,
                            unfocusedContainerColor = OffWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Preset chips
                    Text("Quick Presets:", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presetPrompts) { prompt ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(BrandBlueSubtle)
                                    .border(1.dp, BrandBlueBorder, RoundedCornerShape(8.dp))
                                    .clickable { userFocus = prompt.drop(3) }
                                    .padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Text(prompt, color = BrandBlueDark, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Time configurations
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = wakeTime,
                            onValueChange = { wakeTime = it },
                            label = { Text("Wake Time") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = BrandBlue,
                                unfocusedBorderColor = BorderLight
                            )
                        )
                        OutlinedTextField(
                            value = sleepTime,
                            onValueChange = { sleepTime = it },
                            label = { Text("Sleep Time") },
                            modifier = Modifier.weight(1f),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = BrandBlue,
                                unfocusedBorderColor = BorderLight
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Generate Button in Brand Blue
                    Button(
                        onClick = {
                            viewModel.generateDailyPlan(
                                userPrompt = userFocus,
                                wakeTime = wakeTime,
                                sleepTime = sleepTime,
                                hoursDeepWork = deepWorkHours,
                                energyPeak = energyPeak
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("generate_plan_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BrandBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Build Plan with Gemini",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // AI Generation Result State
        when (val state = plannerState) {
            is AiPlannerUiState.Idle -> {
                item {
                    EmptyPlannerState()
                }
            }
            is AiPlannerUiState.Loading -> {
                item {
                    LoadingPlannerState()
                }
            }
            is AiPlannerUiState.Error -> {
                item {
                    ErrorPlannerState(
                        message = state.message,
                        onRetry = {
                            viewModel.generateDailyPlan(
                                userPrompt = userFocus,
                                wakeTime = wakeTime,
                                sleepTime = sleepTime,
                                hoursDeepWork = deepWorkHours,
                                energyPeak = energyPeak
                            )
                        }
                    )
                }
            }
            is AiPlannerUiState.Success -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = CardDefaults.outlinedCardBorder().copy(
                            brush = Brush.horizontalGradient(listOf(BrandBlue, BrandBlueBorder))
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = BrandBlue)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Plan Generated (${state.blocks.size} blocks)",
                                        color = BrandBlue,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = state.summary, color = TextPrimary, fontSize = 13.sp)

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = { viewModel.applyPlanToToday() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("apply_plan_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = BrandBlue,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Apply to Today's Timeline", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                items(state.blocks) { block ->
                    PlanPreviewCard(block = block)
                }
            }
        }
    }
}

@Composable
private fun PlanPreviewCard(block: PlanBlock) {
    val categoryColor = Color(block.category.colorHex)
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(categoryColor.copy(alpha = 0.4f), BorderLight)))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${block.timeStart} - ${block.timeEnd}",
                    color = categoryColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "${block.energyLevel.emoji} ${block.energyLevel.label}",
                    color = TextMuted,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = block.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (block.description.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = block.description, color = TextSecondary, fontSize = 12.sp)
            }
            if (block.tips.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "Focus Tip: ${block.tips}", color = BrandBlue, fontSize = 11.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
            }
        }
    }
}

@Composable
private fun EmptyPlannerState() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BorderLight, BorderLight)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Schedule,
                contentDescription = null,
                tint = BrandBlue.copy(alpha = 0.5f),
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("Ready to craft your day", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(
                "Click 'Build Plan with Gemini' above to generate an intelligent time-blocked schedule.",
                color = TextMuted,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}

@Composable
private fun LoadingPlannerState() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BrandBlueBorder, BorderLight)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CircularProgressIndicator(color = BrandBlue, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.height(12.dp))
            Text("Gemini 3.8-flash is strategizing your day...", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text("Balancing deep work, energy levels & buffer recovery", color = TextMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ErrorPlannerState(message: String, onRetry: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ErrorRed, BorderLight)))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Generation Failed", color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(message, color = TextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue, contentColor = Color.White)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Retry")
            }
        }
    }
}

// ----------------- TAB 2: Goal Architect ----------------- //

@Composable
private fun GoalArchitectTab(viewModel: LifeOsViewModel) {
    val goalState by viewModel.goalState.collectAsState()
    val savedGoals by viewModel.savedGoals.collectAsState()

    var goalPrompt by remember { mutableStateOf("Build and launch an AI-powered Android app on Play Store") }
    var timeframe by remember { mutableStateOf("30 Days") }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(16.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.linearGradient(listOf(BrandBlueBorder, BorderLight))
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Goal Architect & Phase Decomposer",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Turn ambiguous ambitions into 3-4 phased roadmaps with weekly milestones and daily habits.",
                        color = TextMuted,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = goalPrompt,
                        onValueChange = { goalPrompt = it },
                        modifier = Modifier.fillMaxWidth().testTag("goal_prompt_input"),
                        label = { Text("What is your major goal?") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = BorderLight
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Target Timeframe:", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("14 Days", "30 Days", "60 Days", "90 Days").forEach { tf ->
                            val isSel = tf == timeframe
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) BrandBlueSubtle else OffWhite)
                                    .border(1.dp, if (isSel) BrandBlue else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { timeframe = tf }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(tf, color = if (isSel) BrandBlueDark else TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = { viewModel.generateGoalBlueprint(goalPrompt, timeframe) },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("decompose_goal_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = BrandBlue, contentColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Decompose Goal with Gemini", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Goal state display
        when (val state = goalState) {
            is AiGoalUiState.Idle -> {}
            is AiGoalUiState.Loading -> {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator(color = BrandBlue, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("Architecting phased roadmap...", color = TextPrimary, fontSize = 14.sp)
                        }
                    }
                }
            }
            is AiGoalUiState.Error -> {
                item {
                    Text("Error: ${state.message}", color = ErrorRed)
                }
            }
            is AiGoalUiState.Success -> {
                val bp = state.blueprint
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                        shape = RoundedCornerShape(16.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BrandBlue, BorderLight)))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Strategic Roadmap: ${bp.title}", color = BrandBlueDark, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(bp.summaryStrategy, color = TextPrimary, fontSize = 13.sp)

                            if (bp.immediateNextAction.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(BrandBlueSubtle, RoundedCornerShape(8.dp))
                                        .border(1.dp, BrandBlueBorder, RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                ) {
                                    Text("⚡ First 24-Hour Action: ${bp.immediateNextAction}", color = BrandBlueDark, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.saveGoalToLifeOs(bp) },
                                modifier = Modifier.fillMaxWidth().height(44.dp).testTag("save_goal_btn"),
                                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue, contentColor = Color.White)
                            ) {
                                Text("Save Goal & Auto-Add Habits", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                items(bp.phases) { phase ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                        shape = RoundedCornerShape(12.dp),
                        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BorderLight, BorderLight)))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Phase ${phase.phaseNumber}: ${phase.phaseName}",
                                color = BrandBlueDark,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(text = phase.focusDescription, color = TextSecondary, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            phase.milestones.forEach { m ->
                                Row(
                                    modifier = Modifier.padding(vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(modifier = Modifier.size(6.dp).background(BrandBlue, CircleShape))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(text = m, color = TextPrimary, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Active Saved Goals
        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Active Goal Roadmaps (${savedGoals.size})", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        items(savedGoals) { goal ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BorderLight, BorderLight)))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = goal.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = goal.targetTimeframe, color = BrandBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = goal.summaryStrategy, color = TextSecondary, fontSize = 12.sp, maxLines = 2)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = "Phases: ${goal.phases.size} | Habits: ${goal.suggestedDailyHabits.size}", color = BrandBlueDark, fontSize = 11.sp)
                }
            }
        }
    }
}
