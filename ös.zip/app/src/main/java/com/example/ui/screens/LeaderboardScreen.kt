package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.North
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Racer
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueBorder
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.LifeOsViewModel
import com.example.viewmodel.OsScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LeaderboardScreen(
    viewModel: LifeOsViewModel,
    modifier: Modifier = Modifier
) {
    val racers by viewModel.racers.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    var selectedFilterIndex by remember { mutableIntStateOf(0) }
    val filterOptions = listOf("Weekly XP", "Focus Stamina", "Task Velocity")

    val sortedRacers = remember(racers, selectedFilterIndex) {
        when (selectedFilterIndex) {
            1 -> racers.sortedByDescending { it.focusHours }
            2 -> racers.sortedByDescending { it.tasksDone }
            else -> racers.sortedByDescending { it.xp }
        }
    }

    val top3 = racers.sortedByDescending { it.xp }.take(3)
    val currentUserRacer = racers.find { it.isCurrentUser } ?: racers.getOrNull(1)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhite)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { viewModel.navigateTo(OsScreen.DASHBOARD) },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(SurfaceWhite)
                            .border(1.dp, BorderLight, CircleShape)
                            .testTag("leaderboard_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "League Race 🏆",
                            color = TextPrimary,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Diamond League • Week 45 Race",
                            color = BrandBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(BrandBlueSubtle)
                        .border(1.dp, BrandBlueBorder, RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = BrandBlueDark,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "2d 14h left",
                            color = BrandBlueDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2. Current User Race Standing Hero Card
        if (currentUserRacer != null) {
            item {
                UserRaceStandingHero(
                    racer = currentUserRacer,
                    firstPlaceXp = racers.firstOrNull()?.xp ?: 4820,
                    onStartFocus = { viewModel.navigateTo(OsScreen.FOCUS_TIMER) },
                    onBoost = { viewModel.boostRaceXp(100, "Deep Focus Sprint boost") }
                )
            }
        }

        // 3. Visual 3D Podium (1st, 2nd, 3rd)
        if (top3.size >= 3) {
            item {
                PodiumSection(top3 = top3)
            }
        }

        // 4. Filter Chips
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                filterOptions.forEachIndexed { index, title ->
                    val isSelected = selectedFilterIndex == index
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) BrandBlue else SurfaceWhite)
                            .border(1.dp, if (isSelected) BrandBlue else BorderLight, RoundedCornerShape(10.dp))
                            .clickable { selectedFilterIndex = index }
                            .padding(horizontal = 12.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = title,
                            color = if (isSelected) Color.White else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        // 5. Full Leaderboard Race Table
        item {
            Text(
                text = "Live Race Standings",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(sortedRacers, key = { it.id }) { racer ->
            RacerRowCard(
                racer = racer,
                filterIndex = selectedFilterIndex
            )
        }

        // 6. How to Race & Win XP Guide Card
        item {
            RaceRulesGuideCard()
        }
    }
}

/**
 * Top Card showing user's live position in the race.
 */
@Composable
private fun UserRaceStandingHero(
    racer: Racer,
    firstPlaceXp: Int,
    onStartFocus: () -> Unit,
    onBoost: () -> Unit
) {
    val xpGap = (firstPlaceXp - racer.xp).coerceAtLeast(0)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BrandBlueBorder))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(BrandBlueSubtle.copy(alpha = 0.5f), SurfaceWhite)
                    )
                )
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(BrandBlue)
                                .border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚡", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${racer.name} (You)",
                                    color = TextPrimary,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(BrandBlue)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("PROMOTING", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(
                                text = "Rank #${racer.rank} in Diamond League",
                                color = BrandBlueDark,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "${racer.xp} XP",
                            color = BrandBlue,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = if (xpGap > 0) "-$xpGap XP to #1" else "Current #1 Leader!",
                            color = if (xpGap > 0) TextMuted else Color(0xFF059669),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stats strip: Focus hours, Tasks Done, Streak
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceWhite)
                        .border(1.dp, BorderLight, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RaceStatItem(label = "Focus Hours", value = "%.1fh".format(racer.focusHours), emoji = "⏱️")
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(BorderLight))
                    RaceStatItem(label = "Tasks Done", value = "${racer.tasksDone}", emoji = "✅")
                    Box(modifier = Modifier.width(1.dp).height(24.dp).background(BorderLight))
                    RaceStatItem(label = "Day Streak", value = "${racer.streakDays}d", emoji = "🔥")
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandBlue)
                            .clickable(onClick = onStartFocus)
                            .padding(vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Timer, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Start Focus Sprint", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceWhite)
                            .border(1.dp, BrandBlueBorder, RoundedCornerShape(10.dp))
                            .clickable(onClick = onBoost)
                            .padding(horizontal = 14.dp, vertical = 9.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Bolt, contentDescription = null, tint = BrandBlue, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("+100 XP", color = BrandBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RaceStatItem(label: String, value: String, emoji: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 11.sp)
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = value, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        Text(text = label, color = TextMuted, fontSize = 10.sp)
    }
}

/**
 * Top 3 Racers Podium (2nd, 1st, 3rd layout).
 */
@Composable
private fun PodiumSection(top3: List<Racer>) {
    val first = top3.getOrNull(0) ?: return
    val second = top3.getOrNull(1) ?: return
    val third = top3.getOrNull(2) ?: return

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "WEEKLY PODIUM",
                color = BrandBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(170.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                // 2nd Place (Silver)
                PodiumColumn(
                    racer = second,
                    rank = 2,
                    pedestalHeight = 90.dp,
                    badge = "🥈 2nd",
                    pedestalColor = Color(0xFFE2E8F0),
                    crown = null
                )

                // 1st Place (Gold)
                PodiumColumn(
                    racer = first,
                    rank = 1,
                    pedestalHeight = 120.dp,
                    badge = "🥇 1st",
                    pedestalColor = Color(0xFFFEF3C7),
                    crown = "👑"
                )

                // 3rd Place (Bronze)
                PodiumColumn(
                    racer = third,
                    rank = 3,
                    pedestalHeight = 75.dp,
                    badge = "🥉 3rd",
                    pedestalColor = Color(0xFFFFEDD5),
                    crown = null
                )
            }
        }
    }
}

@Composable
private fun PodiumColumn(
    racer: Racer,
    rank: Int,
    pedestalHeight: androidx.compose.ui.unit.Dp,
    badge: String,
    pedestalColor: Color,
    crown: String?
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom,
        modifier = Modifier.width(96.dp)
    ) {
        if (crown != null) {
            Text(crown, fontSize = 16.sp)
        }

        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (racer.isCurrentUser) BrandBlue else SurfaceWhite)
                .border(2.dp, if (racer.isCurrentUser) BrandBlue else BorderLight, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(racer.avatarEmoji, fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = racer.name,
            color = if (racer.isCurrentUser) BrandBlueDark else TextPrimary,
            fontSize = 11.sp,
            fontWeight = if (racer.isCurrentUser) FontWeight.ExtraBold else FontWeight.SemiBold,
            maxLines = 1
        )

        Text(
            text = "${racer.xp} XP",
            color = BrandBlue,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Pedestal
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(pedestalHeight)
                .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                .background(pedestalColor)
                .border(1.dp, BorderLight, RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = badge,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }
        }
    }
}

/**
 * Single racer row in the race standings table.
 */
@Composable
private fun RacerRowCard(
    racer: Racer,
    filterIndex: Int
) {
    val isCurrentUser = racer.isCurrentUser
    val rankColor = when (racer.rank) {
        1 -> Color(0xFFD97706)
        2 -> Color(0xFF64748B)
        3 -> Color(0xFFB45309)
        else -> TextMuted
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("racer_row_${racer.rank}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCurrentUser) BrandBlueSubtle.copy(alpha = 0.5f) else SurfaceWhite
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = SolidColor(if (isCurrentUser) BrandBlue else BorderLight)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Rank Number / Badge
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (racer.rank <= 3) rankColor.copy(alpha = 0.15f) else OffWhite),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "#${racer.rank}",
                        color = rankColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Avatar
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(SurfaceWhite)
                        .border(1.dp, BorderLight, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(racer.avatarEmoji, fontSize = 16.sp)
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = racer.name,
                            color = if (isCurrentUser) BrandBlueDark else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = if (isCurrentUser) FontWeight.ExtraBold else FontWeight.Bold
                        )
                        if (isCurrentUser) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "(You)",
                                color = BrandBlue,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Secondary metric based on selected filter
                    val secondaryText = when (filterIndex) {
                        1 -> "%.1fh Focus • ${racer.tasksDone} tasks".format(racer.focusHours)
                        2 -> "${racer.tasksDone} tasks • %.1fh Focus".format(racer.focusHours)
                        else -> "%.1fh Focus • ${racer.streakDays}d streak".format(racer.focusHours)
                    }
                    Text(
                        text = secondaryText,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            // Right side: XP & Status badge
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${racer.xp} XP",
                    color = BrandBlue,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Text(
                    text = racer.statusBadge,
                    color = when {
                        racer.rank <= 3 -> Color(0xFF059669)
                        racer.rank >= 7 -> Color(0xFFDC2626)
                        else -> TextMuted
                    },
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * Race Scoring Rules Guide Card.
 */
@Composable
private fun RaceRulesGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.MilitaryTech,
                    contentDescription = null,
                    tint = BrandBlue,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "How Race XP Works",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RuleItem("⚡ Complete Priority Task", "+50 XP per item")
                RuleItem("⏱️ Deep Focus Sprint", "+2 XP per focus minute (+50 XP / 25m)")
                RuleItem("🔥 Maintain Daily Habits", "+30 XP per completed habit")
                RuleItem("🎯 Decompose & Save Goal", "+250 XP milestone bonus")
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Top 3 racers at Sunday midnight promote to Master League! Bottom 2 relegate.",
                color = TextMuted,
                fontSize = 10.sp
            )
        }
    }
}

@Composable
private fun RuleItem(title: String, points: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = TextSecondary, fontSize = 11.sp)
        Text(points, color = BrandBlueDark, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
