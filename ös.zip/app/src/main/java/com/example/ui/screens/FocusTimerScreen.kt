package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueBorder
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueLight
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.LifeOsViewModel
import com.example.viewmodel.TimerMode
import com.example.viewmodel.TimerStatus

@Composable
fun FocusTimerScreen(
    viewModel: LifeOsViewModel,
    modifier: Modifier = Modifier
) {
    val timerMode by viewModel.timerMode.collectAsState()
    val secondsLeft by viewModel.timerSecondsLeft.collectAsState()
    val timerStatus by viewModel.timerStatus.collectAsState()
    val focusMinutesLogged by viewModel.focusMinutesToday.collectAsState()
    val tasks by viewModel.tasks.collectAsState()

    var selectedTaskId by remember { mutableStateOf<String?>(null) }
    var selectedAmbience by remember { mutableStateOf("Binaural Beats") }

    val totalDurationSeconds = timerMode.durationMinutes * 60
    val progress = if (totalDurationSeconds > 0) {
        (totalDurationSeconds - secondsLeft).toFloat() / totalDurationSeconds
    } else 0f

    val minutes = secondsLeft / 60
    val seconds = secondsLeft % 60
    val formattedTime = "%02d:%02d".format(minutes, seconds)

    // Pulse animation when running
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (timerStatus == TimerStatus.RUNNING) 1.03f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhite)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Header
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = "Focus Engine",
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "High cognitive intensity sprints with zero distraction",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Mode Selector
        item {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(TimerMode.entries) { mode ->
                    val isSelected = mode == timerMode
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) BrandBlueSubtle else SurfaceWhite)
                            .border(1.dp, if (isSelected) BrandBlue else BorderLight, RoundedCornerShape(10.dp))
                            .clickable { viewModel.setTimerMode(mode) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("timer_mode_${mode.name}")
                    ) {
                        Text(
                            text = "${mode.label} (${mode.durationMinutes}m)",
                            color = if (isSelected) BrandBlueDark else TextMuted,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // Circular Timer Gauge in White & Blue
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                // Background Track and Progress
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val strokeWidth = 14.dp.toPx()
                    // Background track in soft blue-gray
                    drawCircle(
                        color = Color(0xFFE2E8F0),
                        style = Stroke(width = strokeWidth)
                    )

                    // Active sweep in vibrant brand blue
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(BrandBlueLight, BrandBlue, BrandBlueDark, BrandBlueLight)
                        ),
                        startAngle = -90f,
                        sweepAngle = progress * 360f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = timerMode.label.uppercase(),
                        color = BrandBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = formattedTime,
                        color = TextPrimary,
                        fontSize = 46.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = when (timerStatus) {
                            TimerStatus.RUNNING -> "🔥 IN DEEP FLOW"
                            TimerStatus.PAUSED -> "PAUSED"
                            TimerStatus.STOPPED -> "READY"
                        },
                        color = if (timerStatus == TimerStatus.RUNNING) BrandBlue else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Action Controls (Start / Pause / Reset)
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.resetTimer() },
                    modifier = Modifier
                        .size(50.dp)
                        .background(SurfaceWhite, CircleShape)
                        .border(1.dp, BorderLight, CircleShape)
                        .testTag("reset_timer_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = TextMuted)
                }

                Button(
                    onClick = {
                        if (timerStatus == TimerStatus.RUNNING) {
                            viewModel.pauseTimer()
                        } else {
                            viewModel.startTimer()
                        }
                    },
                    modifier = Modifier
                        .size(68.dp)
                        .testTag("toggle_timer_btn"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BrandBlue,
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp),
                    shape = CircleShape
                ) {
                    Icon(
                        imageVector = if (timerStatus == TimerStatus.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Start/Pause",
                        modifier = Modifier.size(32.dp),
                        tint = Color.White
                    )
                }
            }
        }

        // Focus Target
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(BrandBlueBorder, BorderLight)))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "Current Focus Objective",
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val openTasks = tasks.filter { !it.isCompleted }
                    if (openTasks.isEmpty()) {
                        Text("No active tasks. Freeform focus.", color = TextMuted, fontSize = 12.sp)
                    } else {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(openTasks) { task ->
                                val isSelected = task.id == selectedTaskId
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) BrandBlueSubtle else OffWhite)
                                        .border(1.dp, if (isSelected) BrandBlue else BorderLight, RoundedCornerShape(8.dp))
                                        .clickable { selectedTaskId = if (isSelected) null else task.id }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = task.title,
                                        color = if (isSelected) BrandBlueDark else TextSecondary,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ambient Background Sound selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BorderLight, BorderLight)))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Soundscape Ambience", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Simulated Audio Flow", color = BrandBlue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    val ambienceList = listOf("Binaural Beats", "Ocean Rain", "White Noise", "Deep Space")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ambienceList.forEach { amb ->
                            val isSel = amb == selectedAmbience
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSel) BrandBlueSubtle else OffWhite)
                                    .border(1.dp, if (isSel) BrandBlue else BorderLight, RoundedCornerShape(8.dp))
                                    .clickable { selectedAmbience = amb }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = amb,
                                    color = if (isSel) BrandBlueDark else TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }

        // Focus stats in clean White & Blue
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = Brush.linearGradient(listOf(BorderLight, BorderLight)))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Today's Focus", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${focusMinutesLogged}m", color = BrandBlue, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Daily Target", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("120m", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Deep Sprints", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${focusMinutesLogged / 25}", color = BrandBlueDark, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
