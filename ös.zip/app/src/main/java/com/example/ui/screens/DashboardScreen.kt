package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BlockCategory
import com.example.model.PlanBlock
import com.example.model.UserProfile
import com.example.ui.theme.BorderLight
import com.example.ui.theme.BrandBlue
import com.example.ui.theme.BrandBlueBorder
import com.example.ui.theme.BrandBlueDark
import com.example.ui.theme.BrandBlueSubtle
import com.example.ui.theme.OffWhite
import com.example.ui.theme.SurfaceWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.LifeOsViewModel
import com.example.viewmodel.OsScreen
import com.example.viewmodel.TimerStatus

@Composable
fun DashboardScreen(
    viewModel: LifeOsViewModel,
    modifier: Modifier = Modifier
) {
    val userProfile by viewModel.userProfile.collectAsState()
    val scheduleBlocks by viewModel.scheduleBlocks.collectAsState()
    val metrics by viewModel.dailyMetrics.collectAsState()
    val timerStatus by viewModel.timerStatus.collectAsState()
    val timerSecondsLeft by viewModel.timerSecondsLeft.collectAsState()
    val timerMode by viewModel.timerMode.collectAsState()

    var showAddBlockDialog by remember { mutableStateOf(false) }
    var selectedDayIndex by remember { mutableIntStateOf(2) } // Wednesday (Today, Nov 11)
    var quickAiPrompt by remember { mutableStateOf("") }

    val daysOfWeek = listOf(
        Pair("Mon", "9"),
        Pair("Tue", "10"),
        Pair("Wed", "11"),
        Pair("Thu", "12"),
        Pair("Fri", "13"),
        Pair("Sat", "14"),
        Pair("Sun", "15")
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OffWhite)
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Top Bar: ÖS Identity & League Race Pill on Left/Right + Settings
        item {
            MainPageTopBar(
                userProfile = userProfile,
                onRaceClick = { viewModel.navigateTo(OsScreen.LEADERBOARD) },
                onSettingsClick = { viewModel.navigateTo(OsScreen.SETTINGS) }
            )
        }

        // 2. Inspiring Welcoming Section with Dynamic Rotating Quotes
        item {
            MainPageWelcomeCard(
                userProfile = userProfile,
                onPlanDayClick = { viewModel.navigateTo(OsScreen.AI_PLANNER) },
                onOpenTasksClick = { viewModel.navigateTo(OsScreen.TASKS) },
                onOpenChatClick = { viewModel.navigateTo(OsScreen.AI_CHAT) }
            )
        }

        // 3. Weekly Day Selector Strip
        item {
            CalendarDayStrip(
                days = daysOfWeek,
                selectedIndex = selectedDayIndex,
                onSelectDay = { selectedDayIndex = it }
            )
        }

        // 4. AI Quick Day Planner Input
        item {
            AiQuickPlanInputBar(
                prompt = quickAiPrompt,
                onPromptChange = { quickAiPrompt = it },
                onSubmit = {
                    if (quickAiPrompt.isNotBlank()) {
                        viewModel.generateDailyPlan(userPrompt = quickAiPrompt)
                        quickAiPrompt = ""
                        viewModel.navigateTo(OsScreen.AI_PLANNER)
                    }
                }
            )
        }

        // 5. Active Focus Session Bar
        item {
            MinimalistFocusBar(
                timerStatus = timerStatus,
                secondsLeft = timerSecondsLeft,
                totalSeconds = timerMode.durationMinutes * 60,
                modeLabel = timerMode.label,
                onTogglePlay = {
                    if (timerStatus == TimerStatus.RUNNING) {
                        viewModel.pauseTimer()
                    } else {
                        viewModel.startTimer()
                    }
                },
                onCardClick = { viewModel.navigateTo(OsScreen.FOCUS_TIMER) }
            )
        }

        // 6. Daily Momentum Summary (Focus & Task progress)
        item {
            MinimalistMetricsSummary(metrics = metrics)
        }

        // 7. Today's Timeline Schedule Header & Blocks
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(BrandBlue, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Today's Schedule & Priorities",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                TextButton(
                    onClick = { showAddBlockDialog = true },
                    modifier = Modifier.testTag("add_block_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Block",
                        tint = BrandBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Add Block",
                        color = BrandBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Timeline Schedule Blocks
        items(scheduleBlocks, key = { it.id }) { block ->
            MinimalistScheduleCard(
                block = block,
                onToggleComplete = { viewModel.togglePlanBlock(block.id) },
                onDelete = { viewModel.deletePlanBlock(block.id) }
            )
        }
    }

    if (showAddBlockDialog) {
        MinimalistAddBlockDialog(
            onDismiss = { showAddBlockDialog = false },
            onAdd = { title, start, end, cat ->
                viewModel.addPlanBlock(
                    PlanBlock(
                        title = title,
                        timeStart = start,
                        timeEnd = end,
                        category = cat
                    )
                )
                showAddBlockDialog = false
            }
        )
    }
}

/**
 * Top bar with ÖS Branding and League Race indicator.
 * Completely removes any debug pill or text.
 */
@Composable
private fun MainPageTopBar(
    userProfile: UserProfile,
    onRaceClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onRaceClick)
                .padding(vertical = 2.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.os_logo),
                contentDescription = "ÖS Logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "ÖS",
                    color = BrandBlue,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Intelligent Life OS",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(BrandBlueSubtle)
                    .border(1.dp, BrandBlueBorder, RoundedCornerShape(12.dp))
                    .clickable(onClick = onRaceClick)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("header_race_pill")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🥈", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "#2 Diamond",
                        color = BrandBlueDark,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(SurfaceWhite)
                    .border(1.dp, BorderLight, CircleShape)
                    .testTag("header_settings_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

/**
 * Welcoming Section featuring inspirational quotes that rotate/change,
 * greeting the user and offering quick shortcuts to Planner and Tasks.
 */
@Composable
private fun MainPageWelcomeCard(
    userProfile: UserProfile,
    onPlanDayClick: () -> Unit,
    onOpenTasksClick: () -> Unit,
    onOpenChatClick: () -> Unit
) {
    val inspiringQuotes = remember {
        listOf(
            Pair("Focus is a muscle. The more you protect it, the sharper your reality becomes.", "Marcus Aurelius"),
            Pair("We are what we repeatedly do. Excellence, then, is not an act, but a habit.", "Aristotle"),
            Pair("Deep work is the superpower of the 21st century.", "Cal Newport"),
            Pair("The secret of getting ahead is getting started.", "Mark Twain"),
            Pair("You do not rise to the level of your goals. You fall to the level of your systems.", "James Clear"),
            Pair("Discipline equals freedom. Daily disciplines compound into mastery.", "Jocko Willink"),
            Pair("Energy flows where attention goes. Protect your deep focus sprints.", "Robin Sharma"),
            Pair("Simplicity is the prerequisite for reliability and execution speed.", "Edsger W. Dijkstra")
        )
    }

    var quoteIndex by remember { mutableIntStateOf(0) }
    val currentQuote = inspiringQuotes[quoteIndex % inspiringQuotes.size]

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(BrandBlueSubtle.copy(alpha = 0.5f), SurfaceWhite)
                    )
                )
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Welcome back, ${userProfile.name} 👋",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Wednesday, Nov 11 • Gemini 3.8 AI Online",
                            color = BrandBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceWhite)
                            .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                            .clickable {
                                quoteIndex = (quoteIndex + 1) % inspiringQuotes.size
                            }
                            .padding(horizontal = 8.dp, vertical = 5.dp)
                            .testTag("refresh_quote_btn")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Next Quote",
                                tint = BrandBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "New Quote",
                                color = BrandBlueDark,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Dynamic Inspirational Quote Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceWhite)
                        .border(1.dp, BrandBlueBorder, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "“${currentQuote.first}”",
                            color = TextPrimary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "— ${currentQuote.second}",
                            color = BrandBlueDark,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandBlue)
                            .clickable(onClick = onPlanDayClick)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Plan Day",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(SurfaceWhite)
                            .border(1.dp, BorderLight, RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenTasksClick)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = BrandBlue,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Tasks",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1.1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(BrandBlueSubtle)
                            .border(1.dp, BrandBlueBorder, RoundedCornerShape(10.dp))
                            .clickable(onClick = onOpenChatClick)
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("💬", fontSize = 12.sp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Goal Tips",
                                color = BrandBlueDark,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CalendarDayStrip(
    days: List<Pair<String, String>>,
    selectedIndex: Int,
    onSelectDay: (Int) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            days.forEachIndexed { index, (dayName, dayNum) ->
                val isSelected = index == selectedIndex
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) BrandBlueSubtle else Color.Transparent)
                        .border(
                            1.dp,
                            if (isSelected) BrandBlue else Color.Transparent,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectDay(index) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = dayName,
                        color = if (isSelected) BrandBlueDark else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = dayNum,
                        color = if (isSelected) BrandBlueDark else TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun AiQuickPlanInputBar(
    prompt: String,
    onPromptChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = BrandBlue,
                modifier = Modifier.size(17.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = prompt,
                onValueChange = onPromptChange,
                placeholder = { Text("Plan day with Gemini (e.g. 3 deep work blocks)", color = TextTertiary, fontSize = 12.sp) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = Color.Transparent,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent
                ),
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("quick_ai_plan_input")
            )

            IconButton(
                onClick = onSubmit,
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if (prompt.isNotBlank()) BrandBlue else BrandBlueSubtle)
                    .testTag("submit_quick_plan_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = "Send",
                    tint = if (prompt.isNotBlank()) Color.White else BrandBlue,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
private fun MinimalistFocusBar(
    timerStatus: TimerStatus,
    secondsLeft: Int,
    totalSeconds: Int,
    modeLabel: String,
    onTogglePlay: () -> Unit,
    onCardClick: () -> Unit
) {
    val progress = if (totalSeconds > 0) (1f - (secondsLeft.toFloat() / totalSeconds)).coerceIn(0f, 1f) else 0f
    val minutes = secondsLeft / 60
    val secs = secondsLeft % 60
    val timeFormatted = "%02d:%02d".format(minutes, secs)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("minimalist_focus_bar"),
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Info block: clickable to open full timer HUD
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onCardClick)
                        .padding(vertical = 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(if (timerStatus == TimerStatus.RUNNING) BrandBlueSubtle else OffWhite),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = if (timerStatus == TimerStatus.RUNNING) BrandBlueDark else BrandBlue,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$modeLabel Sprint",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (timerStatus == TimerStatus.RUNNING) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(BrandBlue)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text("ACTIVE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Text(
                            text = if (timerStatus == TimerStatus.RUNNING) "Focus in progress..." else "Tap to open HUD",
                            color = if (timerStatus == TimerStatus.RUNNING) BrandBlueDark else TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Time Display and Decoupled Play/Pause Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = timeFormatted,
                        color = TextPrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    IconButton(
                        onClick = onTogglePlay,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (timerStatus == TimerStatus.RUNNING) BrandBlueSubtle else BrandBlue)
                            .border(1.dp, if (timerStatus == TimerStatus.RUNNING) BrandBlueBorder else BrandBlue, CircleShape)
                            .testTag("dashboard_play_button")
                    ) {
                        Icon(
                            imageVector = if (timerStatus == TimerStatus.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (timerStatus == TimerStatus.RUNNING) "Pause" else "Play",
                            tint = if (timerStatus == TimerStatus.RUNNING) BrandBlueDark else Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(CircleShape),
                color = BrandBlue,
                trackColor = OffWhite
            )
        }
    }
}

@Composable
private fun MinimalistMetricsSummary(metrics: com.example.model.DailyOsMetrics) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        MetricSummaryCard(
            title = "Focus Stamina",
            value = "${metrics.focusMinutesLogged}m",
            target = "120m goal",
            progress = (metrics.focusMinutesLogged.toFloat() / 120f).coerceIn(0f, 1f),
            modifier = Modifier.weight(1f)
        )
        MetricSummaryCard(
            title = "Task Matrix",
            value = "${metrics.tasksCompleted}/${metrics.totalTasks}",
            target = "${metrics.completionPercentage}% done",
            progress = if (metrics.totalTasks > 0) metrics.tasksCompleted.toFloat() / metrics.totalTasks else 0f,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun MetricSummaryCard(
    title: String,
    value: String,
    target: String,
    progress: Float,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = SurfaceWhite),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                Text(text = target, color = BrandBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape),
                color = BrandBlue,
                trackColor = OffWhite
            )
        }
    }
}

@Composable
private fun MinimalistScheduleCard(
    block: PlanBlock,
    onToggleComplete: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("schedule_block_${block.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (block.isCompleted) OffWhite else SurfaceWhite
        ),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(BorderLight))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleComplete,
                modifier = Modifier
                    .size(30.dp)
                    .testTag("toggle_block_${block.id}")
            ) {
                Icon(
                    imageVector = if (block.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.CheckCircle,
                    contentDescription = "Toggle Complete",
                    tint = if (block.isCompleted) BrandBlue else TextTertiary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${block.timeStart} - ${block.timeEnd}",
                        color = BrandBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(BrandBlueSubtle, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = block.category.label,
                            color = BrandBlueDark,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = block.title,
                    color = if (block.isCompleted) TextMuted else TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (block.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(26.dp)
                    .testTag("delete_block_${block.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Delete",
                    tint = TextTertiary,
                    modifier = Modifier.size(15.dp)
                )
            }
        }
    }
}

@Composable
fun MinimalistAddBlockDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, start: String, end: String, category: BlockCategory) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("14:00") }
    var end by remember { mutableStateOf("15:30") }
    var selectedCat by remember { mutableStateOf(BlockCategory.DEEP_WORK) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceWhite,
        title = { Text("Add Schedule Block", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Block Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = BrandBlue,
                        unfocusedBorderColor = BorderLight
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("block_title_input")
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = start,
                        onValueChange = { start = it },
                        label = { Text("Start (HH:mm)") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = BorderLight
                        )
                    )
                    OutlinedTextField(
                        value = end,
                        onValueChange = { end = it },
                        label = { Text("End (HH:mm)") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = BrandBlue,
                            unfocusedBorderColor = BorderLight
                        )
                    )
                }

                Text("Category:", color = TextMuted, fontSize = 12.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(BlockCategory.entries) { cat ->
                        val isSel = cat == selectedCat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) BrandBlueSubtle else OffWhite)
                                .border(1.dp, if (isSel) BrandBlue else BorderLight, RoundedCornerShape(8.dp))
                                .clickable { selectedCat = cat }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(cat.label, color = if (isSel) BrandBlueDark else TextSecondary, fontSize = 11.sp, fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank()) onAdd(title, start, end, selectedCat) },
                colors = ButtonDefaults.buttonColors(containerColor = BrandBlue, contentColor = Color.White),
                modifier = Modifier.testTag("confirm_add_block_btn")
            ) {
                Text("Add Block", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextMuted)
            }
        }
    )
}
