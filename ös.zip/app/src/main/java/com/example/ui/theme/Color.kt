package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official ÖS White & Blue Brand Palette
val BrandBlue = Color(0xFF1970E5)       // Primary brand blue (exact from ÖS logo)
val BrandBlueDark = Color(0xFF0F52BA)   // Deep royal blue
val BrandBlueLight = Color(0xFF3B82F6)  // Bright accent blue
val BrandBlueSubtle = Color(0xFFEFF6FF) // Soft tinted blue surface
val BrandBlueBorder = Color(0xFFBFDBFE) // Delicate blue outline
val BrandBlueContainer = Color(0xFFDBEAFE)

// Pure Whites & Clean Grays
val White = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFF8FAFC)        // Clean page background
val SurfaceWhite = Color(0xFFFFFFFF)    // Card surfaces
val SurfaceHover = Color(0xFFF1F5F9)    // Subtle hover / inactive
val BorderLight = Color(0xFFE2E8F0)     // Clean divider / border

// High-Contrast Deep Navy Typography
val TextPrimary = Color(0xFF0F172A)     // Deep slate navy for headings
val TextSecondary = Color(0xFF334155)   // Body slate
val TextMuted = Color(0xFF64748B)       // Subtitle / caption
val TextTertiary = Color(0xFF94A3B8)    // Subtle hint text

// Functional Accents
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenLight = Color(0xFFECFDF5)
val WarningAmber = Color(0xFFF59E0B)
val WarningAmberLight = Color(0xFFFFFBEB)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedLight = Color(0xFFFEF2F2)
