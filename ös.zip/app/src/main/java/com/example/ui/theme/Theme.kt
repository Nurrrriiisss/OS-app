package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val OsColorScheme = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = BrandBlueSubtle,
    onPrimaryContainer = BrandBlueDark,
    secondary = BrandBlueLight,
    onSecondary = Color.White,
    secondaryContainer = BrandBlueContainer,
    onSecondaryContainer = BrandBlueDark,
    tertiary = BrandBlueDark,
    onTertiary = Color.White,
    background = OffWhite,
    onBackground = TextPrimary,
    surface = SurfaceWhite,
    onSurface = TextPrimary,
    surfaceVariant = BrandBlueSubtle,
    onSurfaceVariant = TextSecondary,
    outline = BorderLight,
    outlineVariant = BrandBlueBorder,
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun LifeOsTheme(
    darkTheme: Boolean = false, // Forced crisp White & Blue design per user specification
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OsColorScheme,
        typography = Typography,
        content = content
    )
}
