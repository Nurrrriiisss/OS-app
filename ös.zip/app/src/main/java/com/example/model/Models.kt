package com.example.model

import java.util.UUID

enum class BlockCategory(val label: String, val colorHex: Long) {
    DEEP_WORK("Deep Work", 0xFF1970E5),
    STUDY("Learning", 0xFF2563EB),
    HEALTH("Health & Fitness", 0xFF059669),
    MEETING("Communication", 0xFF0284C7),
    ADMIN("Admin & Chores", 0xFF475569),
    RECOVERY("Rest & Reset", 0xFFD97706)
}

enum class EnergyLevel(val label: String, val emoji: String) {
    HIGH("Peak Energy", "⚡"),
    MODERATE("Steady Focus", "🔋"),
    LOW("Low Energy", "☕")
}

data class PlanBlock(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val timeStart: String, // e.g. "09:00"
    val timeEnd: String,   // e.g. "10:30"
    val category: BlockCategory = BlockCategory.DEEP_WORK,
    val isCompleted: Boolean = false,
    val energyLevel: EnergyLevel = EnergyLevel.HIGH,
    val tips: String = ""
)

enum class TaskPriority(val label: String, val badge: String, val colorHex: Long) {
    P1_URGENT("P1 Urgent", "🔥 P1", 0xFFDC2626),
    P2_IMPORTANT("P2 Important", "⭐ P2", 0xFFD97706),
    P3_ROUTINE("P3 Routine", "📋 P3", 0xFF1970E5)
}

data class Subtask(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val isCompleted: Boolean = false
)

data class TaskItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: String = "General",
    val priority: TaskPriority = TaskPriority.P2_IMPORTANT,
    val dueDate: String = "Today",
    val isCompleted: Boolean = false,
    val subtasks: List<Subtask> = emptyList(),
    val aiSuggested: Boolean = false
)

data class HabitItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val category: String,
    val iconKey: String = "star",
    val streak: Int = 0,
    val targetDays: Int = 7,
    val completedToday: Boolean = false,
    val last7Days: List<Boolean> = listOf(false, false, false, false, false, false, false)
)

data class NoteItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val timestamp: String = "Just now",
    val tags: List<String> = emptyList(),
    val summary: String? = null,
    val extractedTasks: List<String> = emptyList()
)

data class GoalPhase(
    val phaseNumber: Int,
    val phaseName: String,
    val focusDescription: String,
    val milestones: List<String>
)

data class GoalBlueprint(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val targetTimeframe: String,
    val summaryStrategy: String,
    val phases: List<GoalPhase> = emptyList(),
    val suggestedDailyHabits: List<String> = emptyList(),
    val immediateNextAction: String = ""
)

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val timestamp: String = "Now"
)

data class DailyOsMetrics(
    val tasksCompleted: Int,
    val totalTasks: Int,
    val focusMinutesLogged: Int,
    val habitsCompleted: Int,
    val totalHabits: Int,
    val energyScore: Int = 85 // 0-100
) {
    val completionPercentage: Int
        get() = if (totalTasks + totalHabits == 0) 100
        else (((tasksCompleted + habitsCompleted).toFloat() / (totalTasks + totalHabits)) * 100).toInt()
}

data class ChatPersona(
    val id: String,
    val name: String,
    val emoji: String,
    val tagline: String,
    val systemPrompt: String
)

data class Racer(
    val id: String = UUID.randomUUID().toString(),
    val rank: Int,
    val name: String,
    val avatarEmoji: String,
    val xp: Int,
    val focusHours: Float,
    val tasksDone: Int,
    val streakDays: Int,
    val isCurrentUser: Boolean = false,
    val league: String = "Diamond",
    val statusBadge: String = ""
)

data class UserAchievement(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val description: String,
    val emoji: String,
    val isUnlocked: Boolean = true,
    val unlockedDate: String = "Recently"
)

data class AppReview(
    val id: String = UUID.randomUUID().toString(),
    val author: String,
    val rating: Int, // 1 to 5
    val comment: String,
    val timeAgo: String = "Today",
    val isVerifiedUser: Boolean = true
)

data class UserProfile(
    val name: String = "DAMIR",
    val title: String = "Life OS Architect",
    val statusGreeting: String = "DIAMOND LEAGUE • #2",
    val email: String = "damir.os@life.io",
    val level: Int = 12,
    val xpCurrent: Int = 4350,
    val xpTarget: Int = 5000,
    val overallRating: Float = 4.94f,
    val totalReviews: Int = 186,
    val consistencyScore: Int = 98,
    val focusStaminaScore: Int = 94,
    val taskExecutionScore: Int = 96,
    val weeklyPerformance: List<Pair<String, Int>> = listOf(
        Pair("Mon", 92),
        Pair("Tue", 96),
        Pair("Wed", 89),
        Pair("Thu", 98),
        Pair("Fri", 95),
        Pair("Sat", 88),
        Pair("Sun", 97)
    )
)

data class HealthVitals(
    val sleepScore: Int = 7, // out of 10
    val sleepHours: Float = 7.5f,
    val sportScore: Int = 3, // out of 10
    val sportSessionsThisWeek: Int = 3,
    val stepsToday: Int = 8420,
    val stepsTarget: Int = 10000
) {
    val overallScore: Int get() = 7
}

data class IntelligenceVitals(
    val iqScore: Int = 8, // out of 10
    val eqScore: Int = 85, // out of 100
    val sqStatus: String = "Mindful & Present",
    val sqScore: Int = 90,
    val pqStatus: String = "High Momentum",
    val pqScore: Int = 88
) {
    val overallScore: Int get() = 8
}


